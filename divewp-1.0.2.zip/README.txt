=== DiveWP - WordPress Performance Analyzer and Optimization Tool ===
Contributors: Oleg Petrov
Tags: performance, security, optimization, woocommerce, seo, site health
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

diveWP is easy way to help you speed up the performance, secure and optimize your WordPress site. Our goal is to tell you what are the best practices and what are the issues - clear and simple, dive in and see the results.

== Description ==

🔍 Take control of your WordPress site with DiveWP - your all-in-one site health and performance dashboard. Stop jumping between different tools and get a complete picture of your site's health in one place.

DiveWP provides instant insights into critical aspects of your WordPress site through an intuitive dashboard. Whether you're a site owner, developer, or agency, DiveWP helps you:

✨ WHAT MAKES DIVEWP SPECIAL:
* See all critical site metrics in one unified dashboard
* Get actionable recommendations for improvements
* Monitor performance trends over time
* Generate professional reports for clients
* Stay ahead of potential issues
* Make data-driven decisions for your site

🎯 COMPREHENSIVE INSIGHTS FOR:
* Server Health & Configuration
* Performance & Speed Optimization
* Security Status & Vulnerabilities
* Database Health & Optimization
* WooCommerce Performance (if active)
* SEO Status & Best Practices
* Email System Configuration

💪 PERFECT FOR:
* WordPress Professionals
* Agency Owners
* Site Administrators
* WooCommerce Store Owners
* Anyone who wants to maintain a healthy WordPress site

DiveWP doesn't just show you numbers - it helps you understand what they mean and what to do about them. Each insight comes with clear explanations and specific recommendations for improvement.

DiveWP provides a comprehensive overview of your WordPress site's health and performance through an intuitive dashboard. Get actionable insights and recommendations for:

= Key Features =

* **Server Insights:** Monitor PHP version, MySQL version, memory limits, and other critical server settings
* **Performance Optimization:** Track caching, compression, minification, and other speed optimization factors
* **Security Status:** Check SSL, file permissions, admin security, and other security measures
* **Database Health:** Monitor database size, tables overhead, revisions, and cleanup opportunities
* **WooCommerce Performance:** Analyze cart fragments, session handling, and order management (when WooCommerce is active)
* **SEO Status:** Track SEO plugin usage, sitemap availability, and search engine visibility
* **Email System:** Monitor SMTP configuration, email authentication, and delivery status

= Benefits =

* **Unified Dashboard:** All critical site information in one place
* **Real-time Monitoring:** Instant access to current site status
* **Actionable Insights:** Clear recommendations for improvements
* **Performance Tracking:** Monitor your site's health over time
* **Easy Export:** Print detailed reports for stakeholders

== Installation ==

1. Upload the `divewp` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Access insights via 'DiveWP' in your admin menu

== Frequently Asked Questions ==

= Does this plugin modify any site settings? =

No, DiveWP is a monitoring tool only. It provides insights and recommendations but doesn't make any changes to your site settings.

= Will this plugin slow down my site? =

No, DiveWP runs only in the WordPress admin area and doesn't affect your front-end performance.

= Is WooCommerce required? =

No, WooCommerce is optional. If installed, DiveWP will provide additional WooCommerce-specific insights.

== Screenshots ==

1. Main Dashboard Overview
2. Server Insights Tab
3. Security Status Overview
4. WooCommerce Performance Insights
5. Email System Status

== Changelog ==

= 1.0.1 =
* Added tooltips for detailed insights
* Improved WooCommerce detection
* Enhanced status indicators
* Fixed email log display issues

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.1 =
This version adds tooltips and improves WooCommerce compatibility. Upgrade recommended for all users.

== Additional Information ==

* For support: [Plugin Support Forum](https://wordpress.org/support/plugin/divewp/)
* For documentation: [DiveWP Documentation](https://divewp.com/documentation/)
* Follow development: [GitHub Repository](https://github.com/olegpetrov/divewp)
