jQuery(document).ready(function($) {
    // Initialize with welcome tab
    function initializeWelcomeTab() {
        // Hide all tabs and show welcome tab by default
        $('.divewp-tab-content').removeClass('active');
        $('.divewp-tabs li').removeClass('active');
        $('.divewp-tabs li[data-tab="welcome"]').addClass('active');
        $('#welcome').addClass('active');
    }

    // Call on page load
    initializeWelcomeTab();

    // Tab switching - update to handle both sidebar and card links
    function switchTab(tabId) {
        $('.divewp-tabs li').removeClass('active');
        $('.divewp-tab-content').removeClass('active');

        $('.divewp-tabs li[data-tab="' + tabId + '"]').addClass('active');
        $("#" + tabId).addClass('active');
    }

    // Handle sidebar tab clicks
    $('.divewp-tabs li').on('click', function() {
        var tabId = $(this).attr('data-tab');
        switchTab(tabId);
    });

    // Handle card link clicks
    $('.divewp-status-list .divewp-tab-link').on('click', function(e) {
        e.preventDefault();
        var tabId = $(this).data('tab');
        switchTab(tabId);
    });

    // Print functionality
    $('#divewp-print-report').on('click', function(e) {
        e.preventDefault();
        var activeTab = $('.divewp-tabs li.active').attr('data-tab');
        var errorLogsTab = $('#error-logs').detach();
        $('.divewp-tab-content').addClass('active');
        window.print();
        $('.divewp-tab-content').removeClass('active');
        $('.divewp-main-content').append(errorLogsTab);
        $('.divewp-tabs li[data-tab="' + activeTab + '"]').click();
    });

    // Copy error logs
    $('.divewp-copy-error-logs').on('click', function() {
        var errorLogs = $('.error-logs-content').text();
        var $temp = $("<textarea>");
        $("body").append($temp);
        $temp.val(errorLogs).select();
        document.execCommand("copy");
        $temp.remove();
        alert('Error logs copied to clipboard!');
    });

    // Show preloader
    $('#divewp-preloader').show();
    $('.divewp-wrap').hide();

    // Set a maximum timeout for the preloader (3 seconds)
    var preloaderTimeout = setTimeout(function() {
        $('#divewp-preloader').fadeOut('fast');
        $('.divewp-wrap').fadeIn('fast');
    }, 3000);

    // Try to hide preloader when everything is actually loaded
    $(window).on('load', function() {
        clearTimeout(preloaderTimeout);
        $('#divewp-preloader').fadeOut('fast');
        $('.divewp-wrap').fadeIn('fast');
    });

    // Fallback - hide preloader if something goes wrong
    $(document).on('error', function() {
        $('#divewp-preloader').fadeOut('fast');
        $('.divewp-wrap').fadeIn('fast');
    });

    // Clear error logs
    $('.divewp-clear-error-logs').on('click', function() {
        if (confirm(divewpData.clearLogsConfirm)) {
            $.ajax({
                url: divewpData.ajaxurl,
                method: 'POST',
                data: {
                    action: 'divewp_clear_error_logs',
                    nonce: divewpData.nonce
                },
                success: function(response) {
                    console.log('Server Response:', response); // Debug log
                    if (response.success) {
                        $('.error-logs-content pre').text('');
                        alert(response.data || divewpData.clearLogsSuccess);
                    } else {
                        console.error('Error:', response.data); // Debug log
                        alert(divewpData.clearLogsFailed + ': ' + (response.data || 'Unknown error'));
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', {
                        status: status,
                        error: error,
                        response: xhr.responseText
                    });
                    alert(divewpData.clearLogsFailed + ': ' + error);
                }
            });
        }
    });

    // Add this to the existing JavaScript
    $('.error-logs-content').on('scroll', function() {
        var element = $(this);
        if (Math.round(element.scrollTop() + element.innerHeight()) >= element[0].scrollHeight) {
            element.addClass('scrolled-bottom');
        } else {
            element.removeClass('scrolled-bottom');
        }
    });

    // Add this to your existing JavaScript
    $('#divewp-send-test-email').on('click', function() {
        var $button = $(this);
        var $result = $('#test-email-result');
        
        // Disable button and show spinner
        $button.prop('disabled', true).addClass('loading');
        
        $.ajax({
            url: divewpData.ajaxurl,
            method: 'POST',
            data: {
                action: 'divewp_send_test_email',
                nonce: divewpData.nonce
            },
            success: function(response) {
                if (response.success) {
                    $result.removeClass('notice-error').addClass('notice notice-success').html('<p>' + response.data.message + '</p>').show();
                    // Refresh the email log table after 2 seconds
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    $result.removeClass('notice-success').addClass('notice notice-error').html('<p>' + response.data + '</p>').show();
                }
            },
            error: function() {
                $result.removeClass('notice-success').addClass('notice notice-error')
                    .html('<p>' + divewpData.testEmailFailed + '</p>').show();
            },
            complete: function() {
                // Re-enable button and hide spinner
                $button.prop('disabled', false).removeClass('loading');
            }
        });
    });

    // Update the ChatGPT button click handler
    $('#divewp-send-to-chatgpt').on('click', function(e) {
        e.preventDefault();
        
        // Store current tab state
        var activeTab = $('.divewp-tabs li.active').attr('data-tab');
        
        // Show all tabs temporarily
        $('.divewp-tab-content').addClass('active');
        
        // Get the report content by processing each tab's table
        var reportContent = '';
        $('.divewp-tab-content').each(function() {
            var $tab = $(this);
            // Skip welcome tab and recommendations sections
            if ($tab.attr('id') !== 'welcome') {
                var tabTitle = $tab.find('h3').first().text();
                
                // Only process if it's a main insights section
                if (tabTitle && !tabTitle.includes('Recent Email Log')) {
                    reportContent += '\n\n' + tabTitle + ':\n';
                    
                    // Process table content
                    $tab.find('.divewp-table tr').each(function(index) {
                        if (index > 0) { // Skip header row
                            var $cells = $(this).find('td');
                            if ($cells.length >= 4) {
                                var checkName = $cells.eq(0).text().trim();
                                
                                // Include only specific email configuration checks
                                var isEmailConfig = checkName === 'SMTP Configuration' || 
                                                  checkName === 'Email Authentication' || 
                                                  checkName === 'WP Mail Status';
                                
                                // Skip if it's a date or contains @ symbol (email log entries)
                                var isEmailLog = checkName.match(/^\d{4}/) || 
                                               checkName.includes('@') || 
                                               $cells.eq(1).text().includes('@');
                                
                                if ((isEmailConfig || !$tab.attr('id').includes('email')) && !isEmailLog) {
                                    reportContent += '\n• ' + checkName + ': ' +
                                                  $cells.eq(1).text().trim() + ' | ' +
                                                  'Recommended: ' + $cells.eq(2).text().trim() + ' | ' +
                                                  'Impact: ' + $cells.eq(3).text().trim();
                                }
                            }
                        }
                    });
                }
            }
        });
        
        // Clean up the text
        reportContent = reportContent.trim();
        
        // Create the prompt and full report
        var prompt = "Act as professional WordPress developer and prepare for me action plan to improve my WordPress sites, based on the best practices. I will paste a report of my site's current state and recommendations made by DiveWP plugin, here is the report:";
        var fullReport = prompt + "\n\n" + reportContent;
        
        // Show custom modal
        var modal = $('<div class="divewp-modal">' +
            '<div class="divewp-modal-content">' +
                '<div class="divewp-modal-header">' +
                    '<h3>Ready to Generate AI Action Plan</h3>' +
                    '<div class="copy-status"><span class="dashicons dashicons-yes"></span> Report copied to clipboard</div>' +
                '</div>' +
                '<div class="divewp-modal-steps">' +
                    '<p>Follow these steps:</p>' +
                    '<ol>' +
                        '<li>Click "Open ChatGPT" below</li>' +
                        '<li class="highlight-step">' +
                            '<div class="paste-instruction">' +
                                '<span class="key-combo">' +
                                    (navigator.platform.indexOf('Mac') !== -1 ? '⌘ + V' : 'Ctrl + V') +
                                '</span>' +
                                '<span class="paste-text">Paste in ChatGPT</span>' +
                            '</div>' +
                        '</li>' +
                        '<li>ChatGPT will analyze and create your action plan</li>' +
                    '</ol>' +
                '</div>' +
                '<div class="divewp-modal-buttons">' +
                    '<button class="button button-primary divewp-modal-continue">Open ChatGPT</button>' +
                    '<button class="button divewp-modal-cancel">Cancel</button>' +
                '</div>' +
            '</div>' +
        '</div>');

        // Try to copy to clipboard first
        try {
            navigator.clipboard.writeText(fullReport).then(function() {
                // Add modal to body after successful copy
                $('body').append(modal);
                
                // Handle continue button
                modal.find('.divewp-modal-continue').on('click', function() {
                    window.open('https://chat.openai.com/', '_blank');
                    modal.remove();
                });
                
                // Handle cancel button and outside click
                modal.find('.divewp-modal-cancel').on('click', function() {
                    modal.remove();
                });
                modal.on('click', function(e) {
                    if ($(e.target).is('.divewp-modal')) {
                        modal.remove();
                    }
                });
            }).catch(function(err) {
                alert('Failed to copy report to clipboard. Please try again.');
            });
        } catch (err) {
            alert('Failed to copy report to clipboard. Please try again.');
        }
        
        // Restore original tab state
        $('.divewp-tab-content').removeClass('active');
        $('.divewp-tabs li[data-tab="' + activeTab + '"]').click();
    });
});
