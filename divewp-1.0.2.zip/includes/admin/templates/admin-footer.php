<?php
/**
 * Admin Footer Template
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */
?>
<div class="divewp-footer">
    <p>
        Official DiveWP site - <a href="https://divewp.com" target="_blank">https://divewp.com</a>
    </p>
</div>
