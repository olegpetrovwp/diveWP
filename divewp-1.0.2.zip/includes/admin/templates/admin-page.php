<?php
/**
 * Admin welcome page template for DiveWP
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}
?>
<div class="welcome-content">
    <div class="divewp-notice divewp-notice-info">
        <h3><?php esc_html_e('Welcome to diveWP BETA 1, and Thank you for visiting my talk at WordCamp Sofia 2024!', 'divewp'); ?></h3>
        
        <p>
            <?php 
            esc_html_e(
                'DiveWP is now activated and analyzing your WordPress site configuration.', 
                'divewp'
            ); 
            ?>
        </p>
        <p>
            <?php 
            esc_html_e(
                'To help you optimize your site, DiveWP automatically checks various aspects of your WordPress installation and provides specific recommendations based on your configuration.', 
                'divewp'
            ); 
            ?>
        </p>
        <p>
            <?php 
            esc_html_e(
                'Review the status cards below to see what needs your attention.', 
                'divewp'
            ); 
            ?>
        </p>
    </div>
</div>