<?php
/**
 * Admin Right Sidebar Template
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */
?>
<div class="divewp-sidebar no-print">
    <div class="sidebar-section beta-notice" style="background: linear-gradient(135deg, #FDF2E9 0%, #FAE5D3 100%); border-radius: 8px; padding: 15px; margin-bottom: 20px;">
        <h3 style="color: #c05621; margin-top: 0;">
            <?php _e('🧪 BETA Version', 'divewp'); ?>
        </h3>
        <p style="color: #c05621; font-size: 13px; line-height: 1.4; margin-bottom: 0;">
            <?php _e('Currently, our detection system covers selected popular plugins and configurations. If you have functionality implemented through other means, it might show as "not detected" - this is expected in the beta version.', 'divewp'); ?>
        </p>
    </div>

    <div class="status-legend" id="status-legend">
        <h3><?php _e('Status Legend', 'divewp'); ?></h3>
        <div class="legend-item">
            <span class="status-pill status-pill-success"><?php _e('Optimal', 'divewp'); ?></span>
            <span class="legend-text"><?php _e('Meets or exceeds recommendations', 'divewp'); ?></span>
        </div>
        <div class="legend-item">
            <span class="status-pill status-pill-warning"><?php _e('Warning', 'divewp'); ?></span>
            <span class="legend-text"><?php _e('Could be improved', 'divewp'); ?></span>
        </div>
        <div class="legend-item">
            <span class="status-pill status-pill-danger"><?php _e('Critical', 'divewp'); ?></span>
            <span class="legend-text"><?php _e('Needs attention', 'divewp'); ?></span>
        </div>
        <div class="legend-item">
            <span class="status-pill status-pill-info"><?php _e('Info', 'divewp'); ?></span>
            <span class="legend-text"><?php _e('Informational, with recommendations.', 'divewp'); ?></span>
        </div>
    </div>

    <div class="sidebar-section ai-plan-section">
        <h3><?php _e('Create Optimization Plan with AI', 'divewp'); ?></h3>
        <p class="ai-description">
            <?php _e('Get a customized action plan based on your site analysis. This will:', 'divewp'); ?>
        </p>
        <ul class="ai-features">
            <li><?php _e('Copy your site analysis data', 'divewp'); ?></li>
            <li><?php _e('Open ChatGPT in a new tab', 'divewp'); ?></li>
            <li><?php _e('You\'ll need to paste the data (Ctrl/Cmd+V) into ChatGPT', 'divewp'); ?></li>
        </ul>
        <a href="#" id="divewp-send-to-chatgpt" class="divewp-button">
            <?php _e('Fix with AI!', 'divewp'); ?>
        </a>
    </div>

    <div class="sidebar-section">
        <h3><?php _e('Quick Actions', 'divewp'); ?></h3>
        <ul>
            <li>
                <a href="#" id="divewp-print-report"><?php _e('Print Report', 'divewp'); ?></a>
            </li>
        </ul>
    </div>

    <div class="sidebar-section">
        <h3><?php _e('Helpful Links', 'divewp'); ?></h3>
        <ul>
            <li><a href="https://wordpress.org/support/" target="_blank"><?php _e('WordPress Support', 'divewp'); ?></a></li>
            <li><a href="https://developer.wordpress.org/" target="_blank"><?php _e('WordPress Developer Resources', 'divewp'); ?></a></li>
            <li><a href="https://www.php.net/manual/en/" target="_blank"><?php _e('PHP Documentation', 'divewp'); ?></a></li>
            <li><a href="https://woocommerce.com/documentation/" target="_blank"><?php _e('WooCommerce Documentation', 'divewp'); ?></a></li>
            <li><a href="https://www.google.com/webmasters/tools/home" target="_blank"><?php _e('Google Search Console', 'divewp'); ?></a></li>
        </ul>
    </div>
</div>
