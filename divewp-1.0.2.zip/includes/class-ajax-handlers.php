<?php
/**
 * AJAX Handlers for DiveWP
 *
 * This class handles all AJAX requests for the DiveWP plugin.
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_Ajax_Handlers {
    public function __construct() {
        add_action('wp_ajax_divewp_clear_error_logs', array($this, 'clear_error_logs_handler'));
        add_action('wp_ajax_divewp_send_test_email', array($this, 'send_test_email_handler'));
    }

    public function clear_error_logs_handler() {
        // Security checks
        if (!check_ajax_referer('divewp_nonce', 'nonce', false)) {
            wp_send_json_error(array(
                'message' => __('Security check failed', 'divewp')
            ));
            exit;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array(
                'message' => __('Permission denied', 'divewp')
            ));
            exit;
        }

        // Try to clear the logs
        $error_log_path = ini_get('error_log');
        if (empty($error_log_path)) {
            wp_send_json_error('Error log path not found');
            exit;
        }

        if (!file_exists($error_log_path)) {
            wp_send_json_error('Error log file does not exist');
            exit;
        }

        if (!is_writable($error_log_path)) {
            wp_send_json_error('Error log file is not writable');
            exit;
        }

        // Clear the file
        $result = @file_put_contents($error_log_path, '');
        if ($result === false) {
            wp_send_json_error('Failed to clear error log file');
            exit;
        }

        wp_send_json_success('Error logs cleared successfully');
        exit;
    }

    /**
     * Handle test email sending
     */
    public function send_test_email_handler() {
        // Security checks
        if (!check_ajax_referer('divewp_nonce', 'nonce', false)) {
            wp_send_json_error(array(
                'message' => __('Security check failed', 'divewp')
            ));
            exit;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array(
                'message' => __('Permission denied', 'divewp')
            ));
            exit;
        }

        // Get admin email
        $admin_email = get_option('admin_email');

        // Prepare email content
        $subject = __('DiveWP Test Email', 'divewp');
        $message = sprintf(
            __('This is a test email sent from %s using the DiveWP plugin.', 'divewp'),
            get_bloginfo('name')
        );
        $message .= "\n\n";
        $message .= __('If you received this email, it means your WordPress email functionality is working correctly.', 'divewp');

        // Send email
        $result = wp_mail($admin_email, $subject, $message);

        if ($result) {
            wp_send_json_success(array(
                'message' => __('Test email sent successfully! Check your inbox.', 'divewp')
            ));
        } else {
            wp_send_json_error(__('Failed to send test email. Check your email configuration.', 'divewp'));
        }
    }
}

// Initialize the AJAX handlers
new DiveWP_Ajax_Handlers();
