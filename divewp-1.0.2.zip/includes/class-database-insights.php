<?php
/**
 * Database Insights functionality for DiveWP
 *
 * This class provides database-related insights and recommendations.
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_Database_Insights {
    /**
     * Status constants
     */
    const STATUS_GOOD = 'success';
    const STATUS_WARNING = 'warning';
    const STATUS_CRITICAL = 'danger';
    const STATUS_INFO = 'info';

    /**
     * Get database insights data
     *
     * @since 1.0.0
     * @return array Array of database insights
     */
    public function get_database_data() {
        $data = array(
            'Database Size' => array(
                'value' => $this->get_database_size(),
                'recommended' => __('Depends on content, monitor for sudden increases', 'divewp'),
                'impact' => __('High', 'divewp')
            ),
            'Tables Overhead' => array(
                'value' => $this->get_tables_overhead(),
                'recommended' => __('0 KB - Regular optimization recommended', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'Post Revisions' => array(
                'value' => $this->get_post_revisions_count(),
                'recommended' => __('Keep minimal revisions for important posts', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'Spam Comments' => array(
                'value' => $this->get_spam_comments_count(),
                'recommended' => __('0 - Clean regularly', 'divewp'),
                'impact' => __('Low', 'divewp')
            ),
            'Expired Transients' => array(
                'value' => $this->get_expired_transients_count(),
                'recommended' => __('0 - Clean regularly', 'divewp'),
                'impact' => __('Low', 'divewp')
            ),
            'Non-Core Tables' => array(
                'value' => $this->get_non_core_tables_count(),
                'recommended' => __('Normal Ecommerce sites have around 25 to 50 tables, review regularly', 'divewp'),
                'impact' => __('Info', 'divewp')
            )
        );
        return apply_filters('divewp_database_insights_data', $data);
    }

    /**
     * Get check thresholds
     *
     * @since 1.0.0
     * @return array Check thresholds
     */
    protected function get_check_thresholds() {
        return array(
            'Database Size' => array(
                'optimal' => 100,  // MB
                'warning' => 500   // MB
            ),
            'Tables Overhead' => array(
                'optimal' => 1,    // MB
                'warning' => 10    // MB
            ),
            'Post Revisions' => array(
                'optimal' => 100,
                'warning' => 500
            ),
            'Spam Comments' => array(
                'optimal' => 0,
                'warning' => 100
            ),
            'Expired Transients' => array(
                'optimal' => 0,
                'warning' => 100
            ),
            'Non-Core Tables' => array(
                'optimal' => 50,
                'warning' => 100
            )
        );
    }

    /**
     * Get status pill class
     *
     * @since 1.0.0
     * @param string $key The setting key
     * @param string $value The current value
     * @return string The status pill class
     */
    public function get_pill_class($key, $value) {
        $thresholds = $this->get_check_thresholds();
        
        if (!isset($thresholds[$key])) {
            return 'status-pill-' . self::STATUS_INFO;
        }

        $numeric_value = $this->extract_numeric_value($value);
        
        if ($numeric_value === false) {
            return 'status-pill-' . self::STATUS_INFO;
        }

        if ($numeric_value <= $thresholds[$key]['optimal']) {
            return 'status-pill-' . self::STATUS_GOOD;
        } elseif ($numeric_value <= $thresholds[$key]['warning']) {
            return 'status-pill-' . self::STATUS_WARNING;
        }
        return 'status-pill-' . self::STATUS_CRITICAL;
    }

    /**
     * Extract numeric value from string and convert to MB
     *
     * @since 1.0.0
     * @param string $value The value to extract from
     * @return float|false Numeric value in MB or false if not found
     */
    private function extract_numeric_value($value) {
        if (is_numeric($value)) {
            return floatval($value);
        }
        
        // Extract number and unit from strings like "500 MB" or "90.85 KB" or "1.5 GB"
        if (preg_match('/([0-9.]+)\s*(KB|MB|GB)?/i', $value, $matches)) {
            $number = floatval($matches[1]);
            $unit = isset($matches[2]) ? strtoupper($matches[2]) : '';
            
            // Convert all values to MB for comparison
            switch ($unit) {
                case 'KB':
                    return $number / 1024; // Convert KB to MB
                case 'GB':
                    return $number * 1024; // Convert GB to MB
                case 'MB':
                default:
                    return $number;
            }
        }
        
        return false;
    }

    /**
     * Get database size
     *
     * @since 1.0.0
     * @return string Formatted database size
     */
    private function get_database_size() {
        global $wpdb;
        $size = 0;
        $rows = $wpdb->get_results("SHOW TABLE STATUS");
        
        foreach ($rows as $row) {
            $size += $row->Data_length + $row->Index_length;
        }
        
        return size_format($size, 2);
    }

    /**
     * Get tables overhead
     *
     * @since 1.0.0
     * @return string Formatted overhead size
     */
    private function get_tables_overhead() {
        global $wpdb;
        $overhead = 0;
        $rows = $wpdb->get_results("SHOW TABLE STATUS");
        
        foreach ($rows as $row) {
            $overhead += $row->Data_free;
        }
        
        return size_format($overhead, 2);
    }

    /**
     * Get post revisions count
     *
     * @since 1.0.0
     * @return string Formatted revision count
     */
    private function get_post_revisions_count() {
        global $wpdb;
        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s",
                'revision'
            )
        );
        return number_format_i18n($count);
    }

    /**
     * Get spam comments count
     *
     * @since 1.0.0
     * @return string Formatted spam count
     */
    private function get_spam_comments_count() {
        global $wpdb;
        $count = $wpdb->get_var(
            "SELECT COUNT(*) FROM $wpdb->comments WHERE comment_approved = 'spam'"
        );
        return number_format_i18n($count);
    }

    /**
     * Get expired transients count
     *
     * @since 1.0.0
     * @return string Formatted transients count
     */
    private function get_expired_transients_count() {
        global $wpdb;
        $time = time();
        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $wpdb->options WHERE option_name LIKE %s AND option_value < %d",
                $wpdb->esc_like('_transient_timeout_') . '%',
                $time
            )
        );
        return number_format_i18n($count);
    }

    /**
     * Get non-core tables count
     *
     * @since 1.0.0
     * @return int Count of non-core tables
     */
    private function get_non_core_tables_count() {
        global $wpdb;
        $all_tables = $wpdb->get_col("SHOW TABLES LIKE '{$wpdb->prefix}%'");
        
        $core_tables = array(
            $wpdb->prefix . 'commentmeta',
            $wpdb->prefix . 'comments',
            $wpdb->prefix . 'links',
            $wpdb->prefix . 'options',
            $wpdb->prefix . 'postmeta',
            $wpdb->prefix . 'posts',
            $wpdb->prefix . 'termmeta',
            $wpdb->prefix . 'terms',
            $wpdb->prefix . 'term_relationships',
            $wpdb->prefix . 'term_taxonomy',
            $wpdb->prefix . 'usermeta',
            $wpdb->prefix . 'users'
        );

        $non_core_tables = array_diff($all_tables, $core_tables);
        return count($non_core_tables);
    }

    /**
     * Render database data
     *
     * @since 1.0.0
     * @param array $database_data Database data to render
     * @return void
     */
    public function render_database_data($database_data) {
        if (empty($database_data)) {
            echo '<p>' . esc_html__('No database data available.', 'divewp') . '</p>';
            return;
        }

        echo '<h3>' . esc_html__('Database Insights', 'divewp') . '</h3>';
        echo '<table class="divewp-table">';
        echo '<tr><th>' . esc_html__('Check', 'divewp') . '</th><th>' . esc_html__('Current Value', 'divewp') . '</th><th>' . esc_html__('Recommended', 'divewp') . '</th><th>' . esc_html__('Impact', 'divewp') . '</th></tr>';
        
        foreach ($database_data as $key => $data) {
            echo '<tr>';
            echo '<td><strong>' . esc_html__($key, 'divewp') . '</strong></td>';
            echo '<td><span class="status-pill ' . esc_attr($this->get_pill_class($key, $data['value'])) . '">' . esc_html($data['value']) . '</span></td>';
            echo '<td>' . esc_html($data['recommended']) . '</td>';
            echo '<td>' . esc_html($data['impact']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';

        echo '<div class="database-recommendations no-print">';
        $this->render_database_recommendations();
        echo '</div>';
    }

    private function render_database_recommendations() {
        echo '<h3>' . __('Database Recommendations', 'divewp') . '</h3>';
        echo '<ul>';
        
        // Regular Maintenance
        echo '<li><strong>' . __('Regular Maintenance:', 'divewp') . '</strong> ';
        echo __('Schedule regular database optimization to maintain performance. Consider using a database optimization plugin for automated maintenance. Regular maintenance helps keep your database efficient and reduces overhead.', 'divewp');
        echo '</li>';
        
        // Post Revisions
        echo '<li><strong>' . __('Manage Post Revisions:', 'divewp') . '</strong> ';
        echo __('Limit post revisions by adding <code>define(\'WP_POST_REVISIONS\', 5);</code> to wp-config.php. While revisions are useful for content recovery, too many can bloat your database.', 'divewp');
        echo '</li>';
        
        // Database Size
        echo '<li><strong>' . __('Database Size Management:', 'divewp') . '</strong> ';
        echo __('Large databases are normal for established sites. Focus on managing content like spam comments, transients, and post revisions. Consider regular backups before any cleanup operations.', 'divewp');
        echo '</li>';
        
        // Plugin Tables
        echo '<li><strong>' . __('Plugin Tables:', 'divewp') . '</strong> ';
        echo __('Non-core tables are created by plugins for their functionality. Before removing any tables:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Verify if the plugin is still in use', 'divewp') . '</li>';
        echo '<li>' . __('Check if the plugin has been properly uninstalled', 'divewp') . '</li>';
        echo '<li>' . __('Backup your database before removing any tables', 'divewp') . '</li>';
        echo '<li>' . __('Consider using a specialized database cleanup plugin', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';
        
        // Transients
        echo '<li><strong>' . __('Transients Cleanup:', 'divewp') . '</strong> ';
        echo __('Expired transients are temporary data that WordPress should automatically clean. If you see a large number of expired transients, consider a manual cleanup or using a cleanup plugin.', 'divewp');
        echo '</li>';
        
        echo '</ul>';

        // Add warning box
        echo '<div class="divewp-notice divewp-notice-warning">';
        echo '<p><strong>' . __('Important:', 'divewp') . '</strong> ';
        echo __('Always backup your database before performing any cleanup or optimization operations. Some plugins may store important data in custom tables, and removing them incorrectly could cause issues.', 'divewp');
        echo '</p>';
        echo '</div>';
    }
} 