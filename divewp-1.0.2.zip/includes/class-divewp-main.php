<?php
/**
 * Main DiveWP class
 *
 * This class initializes and manages all DiveWP functionality.
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_Main {
    private $server_insights;
    private $optimization_insights;
    private $security_insights;
    private $woocommerce_insights;
    private $error_logs;
    private $seo_insights;
    private $timing_data = array();
    private $database_insights;
    private $email_insights;
    private $email_logger;
    private $dashboard_overview;

    public function __construct() {
        $this->load_dependencies();
        $this->initialize_components();
        
        // Add admin bar button
        add_action('admin_bar_menu', array($this, 'add_admin_bar_button'), 100);
        
        // Add admin bar styles for all admin pages
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_bar_styles'));

        // Remove other plugins' notices on our page
        add_action('admin_head', array($this, 'remove_notices_on_divewp_page'));
    }

    private function load_dependencies() {
        require_once DIVEWP_PLUGIN_DIR . 'includes/class-server-insights.php';
        require_once DIVEWP_PLUGIN_DIR . 'includes/class-optimization-insights.php';
        require_once DIVEWP_PLUGIN_DIR . 'includes/class-security-insights.php';
        require_once DIVEWP_PLUGIN_DIR . 'includes/class-woocommerce-insights.php';
        require_once DIVEWP_PLUGIN_DIR . 'includes/class-error-logs.php';
        require_once DIVEWP_PLUGIN_DIR . 'includes/class-seo-insights.php';
        require_once DIVEWP_PLUGIN_DIR . 'includes/class-ajax-handlers.php';
        require_once DIVEWP_PLUGIN_DIR . 'includes/class-database-insights.php';
        require_once DIVEWP_PLUGIN_DIR . 'includes/class-email-insights.php';
        require_once DIVEWP_PLUGIN_DIR . 'includes/class-email-logger.php';
        require_once DIVEWP_PLUGIN_DIR . 'includes/class-dashboard-overview.php';
    }

    private function initialize_components() {
        $this->server_insights = new DiveWP_Server_Insights();
        $this->optimization_insights = new DiveWP_Optimization_Insights();
        $this->security_insights = new DiveWP_Security_Insights();
        $this->woocommerce_insights = new DiveWP_WooCommerce_Insights();
        $this->error_logs = new DiveWP_Error_Logs();
        $this->seo_insights = new DiveWP_SEO_Insights();
        $this->database_insights = new DiveWP_Database_Insights();
        $this->email_insights = new DiveWP_Email_Insights();
        $this->email_logger = new DiveWP_Email_Logger();
        $this->dashboard_overview = new DiveWP_Dashboard_Overview();
        new DiveWP_Ajax_Handlers();
    }

    public function run() {
        add_action('admin_menu', array($this, 'add_menu_page'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_styles'));
    }

    public function add_menu_page() {
        add_menu_page(
            'DiveWP',
            'DiveWP',
            'manage_options',
            'divewp',
            array($this, 'render_main_page'),
            'dashicons-performance',
            2
        );
    }

    /**
     * Enqueue admin styles and scripts
     */
    public function enqueue_styles($hook) {
        // Only load on our plugin page
        if ($hook != 'toplevel_page_divewp') {
            return;
        }

        // Enqueue main CSS
        wp_enqueue_style(
            'divewp-style',
            DIVEWP_PLUGIN_URL . 'assets/css/style.css',
            array(),
            DIVEWP_VERSION
        );

        // Enqueue print CSS
        wp_enqueue_style(
            'divewp-print',
            DIVEWP_PLUGIN_URL . 'assets/css/print-style.css',
            array(),
            DIVEWP_VERSION,
            'print'
        );

        // Enqueue JavaScript
        wp_enqueue_script(
            'divewp-admin-js',
            DIVEWP_PLUGIN_URL . 'assets/js/divewp-admin.js',
            array('jquery'),
            DIVEWP_VERSION,
            true
        );

        // Localize script
        wp_localize_script('divewp-admin-js', 'divewpData', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('divewp_nonce'),
            'testEmailFailed' => __('Failed to send test email', 'divewp')
        ));
    }

    public function render_main_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'divewp'));
        }
        ?>
        <div id="divewp-preloader">
            <div class="spinner"></div>
            <p><?php _e('Checking your site...', 'divewp'); ?></p>
        </div>

        <div class="wrap divewp-wrap" style="display: none;">
            <div class="divewp-container">
                <?php include DIVEWP_PLUGIN_DIR . 'includes/admin/templates/admin-left-sidebar.php'; ?>
                <div class="divewp-main-content">
                    <?php
                    // Start timing
                    $start_time = microtime(true);
                    
                    // Welcome tab with dashboard overview
                    $tab_start = microtime(true);
                    echo '<div class="divewp-tab-content active" id="welcome">';
                    include DIVEWP_PLUGIN_DIR . 'includes/admin/templates/admin-page.php';
                    $this->dashboard_overview->render_overview_cards();
                    echo '</div>';
                    $this->log_timing('Welcome Tab', microtime(true) - $tab_start);
                    
                    // Server tab
                    $tab_start = microtime(true);
                    echo '<div class="divewp-tab-content" id="server">';
                    $this->server_insights->render_server_data($this->server_insights->get_server_data());
                    echo '</div>';
                    $this->log_timing('Server Tab', microtime(true) - $tab_start);
                    
                    // Optimization tab
                    $tab_start = microtime(true);
                    echo '<div class="divewp-tab-content" id="optimization">';
                    $this->optimization_insights->render_optimization_data($this->optimization_insights->get_optimization_data());
                    echo '</div>';
                    $this->log_timing('Optimization Tab', microtime(true) - $tab_start);

                    // Database tab
                    $tab_start = microtime(true);
                    echo '<div class="divewp-tab-content" id="database">';
                    $this->database_insights->render_database_data($this->database_insights->get_database_data());
                    echo '</div>';
                    $this->log_timing('Database Tab', microtime(true) - $tab_start);

                    // Security tab
                    $tab_start = microtime(true);
                    echo '<div class="divewp-tab-content" id="security">';
                    $this->security_insights->render_security_data($this->security_insights->get_security_data());
                    echo '</div>';
                    $this->log_timing('Security Tab', microtime(true) - $tab_start);

                    // WooCommerce tab
                    $tab_start = microtime(true);
                    echo '<div class="divewp-tab-content" id="woocommerce">';
                    $this->woocommerce_insights->render_woocommerce_data($this->woocommerce_insights->get_woocommerce_data());
                    echo '</div>';
                    $this->log_timing('WooCommerce Tab', microtime(true) - $tab_start);

                    // SEO tab
                    $tab_start = microtime(true);
                    echo '<div class="divewp-tab-content" id="seo">';
                    $this->seo_insights->render_seo_data($this->seo_insights->get_seo_data());
                    echo '</div>';
                    $this->log_timing('SEO Tab', microtime(true) - $tab_start);

                    // Error Logs tab
                    $tab_start = microtime(true);
                    echo '<div class="divewp-tab-content" id="error-logs">';
                    $this->error_logs->render_error_logs();
                    echo '</div>';
                    $this->log_timing('Error Logs Tab', microtime(true) - $tab_start);

                    // Email Communications tab
                    $tab_start = microtime(true);
                    echo '<div class="divewp-tab-content" id="email">';
                    $this->email_insights->render_email_data($this->email_insights->get_email_data());
                    echo '</div>';
                    $this->log_timing('Email Tab', microtime(true) - $tab_start);

                    // Log total time
                    $this->log_timing('Total Load Time', microtime(true) - $start_time);
                    ?>
                    <?php include DIVEWP_PLUGIN_DIR . 'includes/admin/templates/admin-footer.php'; ?>

                </div>
                <?php include DIVEWP_PLUGIN_DIR . 'includes/admin/templates/admin-right-sidebar.php'; ?>
            </div>
        </div>
        <?php
    }

    private function log_timing($action, $time) {
        $this->timing_data[] = array(
            'action' => $action,
            'time' => number_format($time * 1000, 2) . 'ms'
        );
    }

    private function output_timing_data() {
        if (empty($this->timing_data)) {
            return;
        }

        echo '<div class="timing-data" style="margin-top: 20px; padding: 15px; background: #f8f9fa; border: 1px solid #ddd;">';
        echo '<h3>Loading Times</h3>';
        echo '<table class="divewp-table">';
        echo '<tr><th>Action</th><th>Time</th></tr>';
        
        foreach ($this->timing_data as $timing) {
            echo '<tr>';
            echo '<td>' . esc_html($timing['action']) . '</td>';
            echo '<td>' . esc_html($timing['time']) . '</td>';
            echo '</tr>';
        }
        
        echo '</table>';
        echo '</div>';
    }

    /**
     * Add button to admin bar
     */
    public function add_admin_bar_button($wp_admin_bar) {
        if (!current_user_can('manage_options')) {
            return;
        }

        $wp_admin_bar->add_node(array(
            'id'    => 'divewp-button',
            'title' => 'DiveWP',
            'href'  => admin_url('admin.php?page=divewp'),
            'meta'  => array(
                'class' => 'divewp-admin-button',
                'title' => __('Open DiveWP Dashboard', 'divewp')
            )
        ));
    }

    /**
     * Enqueue admin bar styles
     */
    public function enqueue_admin_bar_styles() {
        wp_enqueue_style(
            'divewp-admin-bar',
            DIVEWP_PLUGIN_URL . 'assets/css/style.css',
            array(),
            DIVEWP_VERSION
        );
    }

    public function remove_notices_on_divewp_page() {
        if (isset($_GET['page']) && $_GET['page'] === 'divewp') {
            remove_all_actions('admin_notices');
            remove_all_actions('all_admin_notices');
            
            // Add back only our notices
            add_action('admin_notices', array($this, 'show_divewp_notices'));
        }
    }

    public function show_divewp_notices() {
        // Empty function - no notices will be shown
        return;
    }
}
