<?php
/**
 * DiveWP Updater Class
 *
 * @package DiveWP
 * @since 1.0.0
 */

defined( 'ABSPATH' ) || exit;

class DiveWP_Updater {
    /**
     * Update API endpoint
     *
     * @var string
     */
    private $update_endpoint;

    /**
     * Current plugin version
     *
     * @var string
     */
    private $current_version;

    /**
     * Plugin basename
     *
     * @var string
     */
    private $plugin_basename;

    /**
     * Initialize the updater
     *
     * @param string $update_endpoint Update API endpoint
     * @param string $current_version Current plugin version
     * @param string $plugin_basename Plugin basename
     */
    public function __construct( $update_endpoint, $current_version, $plugin_basename ) {
        $this->update_endpoint = esc_url_raw( $update_endpoint );
        $this->current_version = sanitize_text_field( $current_version );
        $this->plugin_basename = sanitize_text_field( $plugin_basename );

        add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_for_updates' ) );
        add_filter( 'plugins_api', array( $this, 'plugin_info' ), 10, 3 );
        add_action( 'admin_init', array( $this, 'enforce_ssl' ) );
    }

    /**
     * Enforce SSL for updates
     */
    public function enforce_ssl() {
        if ( ! is_ssl() ) {
            wp_die( 
                esc_html__( 'DiveWP updates require a secure connection (HTTPS).', 'divewp' ),
                esc_html__( 'Security Error', 'divewp' ),
                array( 'response' => 403 )
            );
        }
    }

    /**
     * Check for updates
     *
     * @param object $transient Transient data
     * @return object Modified transient data
     */
    public function check_for_updates( $transient ) {
        if ( empty( $transient->checked ) ) {
            return $transient;
        }

        // Check user capabilities
        if ( ! current_user_can( 'update_plugins' ) ) {
            return $transient;
        }

        $response = wp_safe_remote_get(
            $this->update_endpoint,
            array(
                'timeout'    => 10,
                'sslverify'  => true,
                'headers'    => array(
                    'Accept' => 'application/json',
                ),
            )
        );

        if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
            return $transient;
        }

        $update_data = json_decode( wp_remote_retrieve_body( $response ), true );
        
        if ( 
            version_compare( $this->current_version, $update_data['version'], '<' ) &&
            verify_update_signature( $update_data )
        ) {
            $transient->response[ $this->plugin_basename ] = (object) array(
                'slug'        => 'divewp',
                'new_version' => $update_data['version'],
                'package'     => $update_data['download_url'],
                'tested'      => $update_data['tested'],
                'requires'    => $update_data['requires'],
                'url'         => $update_data['homepage'],
            );
        }

        return $transient;
    }

    /**
     * Verify update signature
     *
     * @param array $update_data Update data
     * @return bool
     */
    private function verify_update_signature( $update_data ) {
        if ( empty( $update_data['signature'] ) ) {
            return false;
        }

        // Implement signature verification logic here
        // This should use proper cryptographic verification
        
        return true;
    }

    /**
     * Provide plugin information for the updates tab
     *
     * @param false|object|array $result Result object/array
     * @param string            $action The type of information being requested
     * @param object            $args   Plugin arguments
     * @return false|object
     */
    public function plugin_info( $result, $action, $args ) {
        if ( 'plugin_information' !== $action ) {
            return $result;
        }

        if ( 'divewp' !== $args->slug ) {
            return $result;
        }

        if ( ! current_user_can( 'update_plugins' ) ) {
            return $result;
        }

        $response = wp_safe_remote_get(
            $this->update_endpoint . '/info',
            array(
                'timeout'    => 10,
                'sslverify'  => true,
                'headers'    => array(
                    'Accept' => 'application/json',
                ),
            )
        );

        if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
            return $result;
        }

        return json_decode( wp_remote_retrieve_body( $response ) );
    }
} 