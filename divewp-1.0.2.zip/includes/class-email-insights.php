<?php
/**
 * Email Communications Insights functionality for DiveWP
 *
 * This class provides email-related insights and recommendations.
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_Email_Insights {
    /**
     * Status constants
     */
    const STATUS_GOOD = 'success';
    const STATUS_WARNING = 'warning';
    const STATUS_CRITICAL = 'danger';
    const STATUS_INFO = 'info';

    /**
     * Get email insights data
     *
     * @since 1.0.0
     * @return array Array of email insights
     */
    public function get_email_data() {
        return array(
            'SMTP Configuration' => array(
                'value' => $this->check_smtp_configuration(),
                'recommended' => __('Should be configured', 'divewp'),
                'impact' => __('High', 'divewp')
            ),
            'Email Authentication' => array(
                'value' => $this->check_spf_dkim(),
                'recommended' => __('SPF/DKIM should be set', 'divewp'),
                'impact' => __('High', 'divewp')
            ),
            'WP Mail Status' => array(
                'value' => $this->check_wp_mail(),
                'recommended' => __('Should be functional', 'divewp'),
                'impact' => __('High', 'divewp')
            )
        );
    }

    /**
     * Get check thresholds
     *
     * @since 1.0.0
     * @return array Check thresholds and status mappings
     */
    protected function get_check_thresholds() {
        return array(
            'status_map' => array(
                self::STATUS_GOOD => array(
                    'Configured',
                    'Available',
                    'Functional'
                ),
                self::STATUS_WARNING => array(
                    'Partially configured',
                    'Limited functionality'
                ),
                self::STATUS_CRITICAL => array(
                    'Not configured',
                    'Not detected',
                    'Not available'
                )
            )
        );
    }

    /**
     * Get status pill class
     *
     * @since 1.0.0
     * @param string $key The setting key
     * @param mixed $value The current value
     * @return string The status pill class
     */
    public function get_pill_class($key, $value) {
        $thresholds = $this->get_check_thresholds();
        
        // Handle array values
        if (is_array($value)) {
            $value = $value['status'];
        }

        // Check status map for text-based statuses
        foreach ($thresholds['status_map'] as $status => $phrases) {
            foreach ($phrases as $phrase) {
                if (strpos($value, $phrase) !== false) {
                    return 'status-pill-' . $status;
                }
            }
        }

        // Default to warning if no match found
        return 'status-pill-' . self::STATUS_WARNING;
    }

    /**
     * Check SMTP configuration
     *
     * @since 1.0.0
     * @return string SMTP configuration status
     */
    private function check_smtp_configuration() {
        if (
            is_plugin_active('wp-mail-smtp/wp_mail_smtp.php') ||
            is_plugin_active('post-smtp/postman-smtp.php') ||
            is_plugin_active('easy-wp-smtp/easy-wp-smtp.php')
        ) {
            return __('Configured', 'divewp');
        }
        return __('Not configured', 'divewp');
    }

    /**
     * Check SPF/DKIM status
     *
     * @since 1.0.0
     * @return string SPF/DKIM status
     */
    private function check_spf_dkim() {
        if (
            is_plugin_active('wp-mail-smtp/wp-mail-smtp.php') && 
            get_option('wp_mail_smtp_auth')
        ) {
            return __('Configured', 'divewp');
        }
        return __('Not detected', 'divewp');
    }

    /**
     * Check WP Mail function status
     *
     * @since 1.0.0
     * @return string WP Mail status
     */
    private function check_wp_mail() {
        return function_exists('wp_mail') ? 
            __('Available', 'divewp') : 
            __('Not available', 'divewp');
    }

    /**
     * Render email data
     *
     * @since 1.0.0
     * @param array $email_data Email data to render
     * @return void
     */
    public function render_email_data($email_data) {
        if (empty($email_data)) {
            echo '<p>' . esc_html__('No email data available.', 'divewp') . '</p>';
            return;
        }

        echo '<h3>' . esc_html__('Email Communications Insights', 'divewp') . '</h3>';
        echo '<table class="divewp-table">';
        echo '<tr><th>' . esc_html__('Check', 'divewp') . '</th><th>' . esc_html__('Status', 'divewp') . '</th><th>' . esc_html__('Recommended', 'divewp') . '</th><th>' . esc_html__('Impact', 'divewp') . '</th></tr>';
        
        foreach ($email_data as $key => $data) {
            echo '<tr>';
            echo '<td><strong>' . esc_html__($key, 'divewp') . '</strong></td>';
            echo '<td><span class="status-pill ' . esc_attr($this->get_pill_class($key, $data['value'])) . '">' . esc_html($data['value']) . '</span></td>';
            echo '<td>' . esc_html($data['recommended']) . '</td>';
            echo '<td>' . esc_html($data['impact']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';

        echo '<div class="email-recommendations no-print">';
        $this->render_email_recommendations();
        echo '</div>';

        // Add test email button above the log table
        echo '<h3 class="email-log-header">' . esc_html__('Recent Email Log', 'divewp') . '</h3>';
        echo '<div class="test-email-section">';
        echo '<button type="button" id="divewp-send-test-email" class="button button-primary">';
        echo '<span class="button-text">' . esc_html__('Send Test Email', 'divewp') . '</span>';
        echo '<span class="spinner"></span>';
        echo '</button>';
        echo '<p class="description">' . esc_html__('This will send a test email to the admin email address and refresh the page to show the new log entry.', 'divewp') . '</p>';
        echo '<div id="test-email-result" style="display: none;"></div>';
        echo '</div>';

        $this->render_email_log();
    }

    /**
     * Render email recommendations
     *
     * @since 1.0.0
     * @return void
     */
    private function render_email_recommendations() {
        echo '<h3>' . esc_html__('Email Communications Recommendations', 'divewp') . '</h3>';
        echo '<ul>';
        
        // Email Delivery
        echo '<li><strong>' . esc_html__('Email Delivery:', 'divewp') . '</strong> ';
        echo esc_html__('Ensure reliable email delivery:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . esc_html__('Configure SMTP for reliable delivery', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Set up SPF and DKIM records', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Use a dedicated email service', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';
        
        // Email Testing
        echo '<li><strong>' . esc_html__('Email Testing:', 'divewp') . '</strong> ';
        echo esc_html__('Regularly test email functionality:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . esc_html__('Test email delivery to different providers', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Monitor email delivery rates', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Check spam scores', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';

        echo '</ul>';

        // Add warning box
        echo '<div class="divewp-notice divewp-notice-warning">';
        echo '<p><strong>' . esc_html__('Important:', 'divewp') . '</strong> ';
        echo esc_html__('Email delivery is crucial for your site. Always test email functionality after making changes and consider using a professional SMTP service for important communications.', 'divewp');
        echo '</p>';
        echo '</div>';
    }

    /**
     * Render email log
     *
     * @since 1.0.0
     * @return void
     */
    private function render_email_log() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'divewp_email_log';
        
        $logs = $wpdb->get_results("SELECT * FROM {$table_name} ORDER BY date_sent DESC LIMIT 100");
        
        if (empty($logs)) {
            echo '<p>' . esc_html__('No emails logged yet.', 'divewp') . '</p>';
            return;
        }
        
        echo '<table class="divewp-table email-log-table">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>' . esc_html__('Date/Time', 'divewp') . '</th>';
        echo '<th>' . esc_html__('Status', 'divewp') . '</th>';
        echo '<th>' . esc_html__('From', 'divewp') . '</th>';
        echo '<th>' . esc_html__('To', 'divewp') . '</th>';
        echo '<th>' . esc_html__('Subject', 'divewp') . '</th>';
        echo '<th>' . esc_html__('Initiator', 'divewp') . '</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        foreach ($logs as $log) {
            $status_class = $log->status === 'sent' ? 'status-pill status-pill-success' : 'status-pill status-pill-danger';
            
            echo '<tr>';
            echo '<td>' . esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), strtotime($log->date_sent))) . '</td>';
            echo '<td><span class="' . esc_attr($status_class) . '">' . esc_html(ucfirst($log->status)) . '</span></td>';
            echo '<td>' . esc_html($log->from_email) . '</td>';
            echo '<td>' . esc_html($log->to_email) . '</td>';
            echo '<td>' . esc_html($log->subject) . '</td>';
            echo '<td>' . esc_html($log->initiator) . '</td>';
            echo '</tr>';
            
            if ($log->status === 'failed' && !empty($log->error_msg)) {
                echo '<tr class="error-details">';
                echo '<td colspan="6">';
                echo '<strong>' . esc_html__('Error:', 'divewp') . '</strong> ' . esc_html($log->error_msg);
                echo '</td>';
                echo '</tr>';
            }
        }
        
        echo '</tbody>';
        echo '</table>';
    }
} 