<?php
/**
 * Email Logger functionality for DiveWP
 *
 * This class handles email logging and management.
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_Email_Logger {
    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'divewp_email_log';
        
        // Create table if it doesn't exist
        $this->maybe_create_table();
        
        // Hook into WordPress email with early priority
        add_filter('wp_mail', array($this, 'log_email_before_send'), 1, 1);
        add_action('wp_mail_failed', array($this, 'log_email_failure'), 1, 1);
        
        // Setup cleanup
        add_action('divewp_daily_cleanup', array($this, 'cleanup_old_logs'));
        if (!wp_next_scheduled('divewp_daily_cleanup')) {
            wp_schedule_event(time(), 'daily', 'divewp_daily_cleanup');
        }
    }

    /**
     * Create the email log table if it doesn't exist
     */
    public function maybe_create_table() {
        global $wpdb;

        // Use get_var with a simpler query
        $table_exists = $wpdb->get_var(
            "SHOW TABLES LIKE '{$this->table_name}'"
        );

        if ($table_exists) {
            return;
        }

        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE {$this->table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            date_sent datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status varchar(20) NOT NULL,
            initiator text NOT NULL,
            from_email varchar(100) NOT NULL,
            to_email varchar(100) NOT NULL,
            subject varchar(255) NOT NULL,
            error_msg text DEFAULT NULL,
            PRIMARY KEY (id),
            KEY date_sent (date_sent),
            KEY status (status)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * Get detailed backtrace information
     */
    private function get_call_trace() {
        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);
        $caller_info = array();
        
        // Get the current hook
        $current_hook = current_filter();
        if ($current_hook) {
            $caller_info[] = "Hook: " . $current_hook;
        }
        
        foreach ($trace as $call) {
            if (isset($call['function'])) {
                // Skip internal WordPress functions and our logging functions
                if (in_array($call['function'], array(
                    'do_action', 
                    'apply_filters', 
                    'log_email_before_send', 
                    'log_email_failure',
                    'get_call_trace'
                ))) {
                    continue;
                }
                
                // Skip if it's our own logging class
                if (isset($call['class']) && $call['class'] === 'DiveWP_Email_Logger') {
                    continue;
                }
                
                $caller = '';
                
                // Add class name if it exists
                if (isset($call['class'])) {
                    // Clean up class name
                    $class_name = str_replace('_', ' ', $call['class']);
                    $caller .= $class_name . $call['type'];
                }
                
                // Add function name
                $caller .= $call['function'];
                
                // Add file and line info if available
                if (isset($call['file']) && isset($call['line'])) {
                    // Clean up file path - remove ABSPATH
                    $file = str_replace(ABSPATH, '', $call['file']);
                    // Clean up plugin path
                    $file = str_replace('wp-content/plugins/divewp 03/', '', $file);
                    $caller .= " ({$file}:{$call['line']})";
                }
                
                $caller_info[] = $caller;
            }
        }
        
        // Return only the most relevant parts of the trace
        // Usually the first 2-3 entries are most useful
        return implode("\n", array_slice($caller_info, 0, 3));
    }

    /**
     * Log email before sending
     */
    public function log_email_before_send($mail_data) {
        global $wpdb;
        
        $wpdb->insert(
            $this->table_name,
            array(
                'status' => 'sent',
                'initiator' => $this->get_call_trace(),
                'from_email' => sanitize_email($mail_data['from'] ?? get_option('admin_email')),
                'to_email' => sanitize_email(is_array($mail_data['to']) ? reset($mail_data['to']) : $mail_data['to']),
                'subject' => sanitize_text_field($mail_data['subject'] ?? ''),
            ),
            array('%s', '%s', '%s', '%s', '%s')
        );

        return $mail_data;
    }

    /**
     * Log failed email
     */
    public function log_email_failure($error) {
        global $wpdb;
        
        $wpdb->insert(
            $this->table_name,
            array(
                'status' => 'failed',
                'initiator' => $this->get_call_trace(),
                'from_email' => sanitize_email($error->from ?? get_option('admin_email')),
                'to_email' => sanitize_email(is_array($error->to) ? reset($error->to) : $error->to),
                'subject' => sanitize_text_field($error->subject ?? ''),
                'error_msg' => sanitize_textarea_field($error->errors['wp_mail_failed'][0] ?? '')
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s')
        );
    }

    /**
     * Keep only last 100 entries
     */
    public function cleanup_old_logs() {
        global $wpdb;
        
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$this->table_name} 
             WHERE id NOT IN (
                 SELECT id FROM (
                     SELECT id FROM {$this->table_name} 
                     ORDER BY date_sent DESC 
                     LIMIT %d
                 ) temp_table
             )",
            100
        ));
    }
} 