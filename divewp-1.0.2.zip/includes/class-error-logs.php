<?php
/**
 * Error Logs functionality for DiveWP
 *
 * This class handles the retrieval and display of error logs.
 *
 * @package DiveWP
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_Error_Logs {
    /**
     * Get error logs with secure path handling
     */
    public function get_error_logs() {
        // Get error log path securely
        $error_log_path = $this->get_secure_error_log_path();
        
        if (is_wp_error($error_log_path)) {
            return new WP_Error(
                'error_log_path_not_set',
                __('Error log path is not configured. To enable error logging:', 'divewp') . 
                '<br>1. ' . __('Add this to wp-config.php:', 'divewp') . 
                '<br><code>define(\'WP_DEBUG\', true);<br>define(\'WP_DEBUG_LOG\', true);</code>'
            );
        }

        if (!$this->validate_log_path($error_log_path)) {
            return new WP_Error(
                'invalid_log_path', 
                sprintf(
                    /* translators: %s: Path to debug.log file */
                    __('Cannot access error log at %s. Please check file permissions or contact your hosting provider.', 'divewp'),
                    '<code>' . esc_html($error_log_path) . '</code>'
                )
            );
        }

        $log_content = @file_get_contents($error_log_path);
        if ($log_content === false) {
            return new WP_Error(
                'error_log_read_failed',
                sprintf(
                    /* translators: %s: Path to debug.log file */
                    __('Unable to read error log file at %s. Please check file permissions (should be 644) or contact your hosting provider.', 'divewp'),
                    '<code>' . esc_html($error_log_path) . '</code>'
                )
            );
        }

        if (empty($log_content)) {
            return new WP_Error(
                'error_log_empty',
                __('No errors have been logged yet. This is good! If you want to test error logging:', 'divewp') .
                '<br>1. ' . __('Make sure WP_DEBUG is enabled in wp-config.php', 'divewp') .
                '<br>2. ' . __('Try accessing a non-existent page to generate a 404 error', 'divewp')
            );
        }

        // Get the last 50 lines of the log
        $lines = explode("\n", $log_content);
        $last_50_lines = array_slice($lines, -50);

        // Sanitize log content
        return $this->sanitize_log_content(implode("\n", $last_50_lines));
    }

    /**
     * Render error logs securely
     */
    public function render_error_logs() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'divewp'));
        }

        echo '<h3>' . esc_html__('Error Logs', 'divewp') . '</h3>';
        
        // Add help text
        echo '<div class="notice notice-info inline">';
        echo '<p>' . esc_html__('Error logs help you identify and fix issues on your WordPress site. They record PHP errors, warnings, and notices.', 'divewp') . '</p>';
        echo '</div>';

        echo '<div class="error-logs-content">';
        
        $logs = $this->get_error_logs();
        
        if (is_wp_error($logs)) {
            printf(
                '<div class="notice notice-error"><p>%s</p></div>',
                wp_kses($logs->get_error_message(), array(
                    'br' => array(),
                    'code' => array()
                ))
            );
            $this->render_error_log_instructions();
        } else {
            echo '<pre>' . esc_html($logs) . '</pre>';
            
            // Add explanation of what users are seeing
            echo '<div class="notice notice-info inline">';
            echo '<p>' . esc_html__('Above are the last 50 error log entries. They show:', 'divewp') . '</p>';
            echo '<ul>';
            echo '<li>' . esc_html__('Date and time of each error', 'divewp') . '</li>';
            echo '<li>' . esc_html__('Error type (Warning, Notice, Fatal Error, etc.)', 'divewp') . '</li>';
            echo '<li>' . esc_html__('Error message and location', 'divewp') . '</li>';
            echo '</ul>';
            echo '</div>';
        }
        
        echo '</div>';
        
        if (current_user_can('manage_options')) {
            echo '<div class="error-logs-actions">';
            echo '<button class="button divewp-copy-error-logs">' . 
                 esc_html__('Copy Error Logs', 'divewp') . 
                 '</button>';
            echo '<button class="button divewp-clear-error-logs">' . 
                 esc_html__('Clear Error Logs', 'divewp') . 
                 '</button>';
            echo '</div>';
            
            // Add action buttons explanation
            echo '<p class="description">';
            echo esc_html__('Use "Copy Error Logs" to share with developers or support. "Clear Error Logs" will empty the log file.', 'divewp');
            echo '</p>';
        }
    }

    /**
     * Clear error logs securely
     */
    public function clear_error_logs() {
        if (!current_user_can('manage_options')) {
            return false;
        }

        $error_log_path = $this->get_secure_error_log_path();
        
        if (is_wp_error($error_log_path) || !$this->validate_log_path($error_log_path)) {
            return false;
        }

        return @file_put_contents($error_log_path, '') !== false;
    }

    /**
     * Get error log path securely
     *
     * @return string|WP_Error
     */
    private function get_secure_error_log_path() {
        $error_log_path = ini_get('error_log');
        
        // If error_log path is not set in PHP configuration
        if (empty($error_log_path)) {
            $error_log_path = WP_CONTENT_DIR . '/debug.log';
        }

        return $error_log_path;
    }

    /**
     * Validate log path
     *
     * @param string $path Path to validate
     * @return bool
     */
    private function validate_log_path($path) {
        if (!$path || !file_exists($path) || !is_readable($path)) {
            return false;
        }

        $real_path = realpath($path);
        $wp_root = realpath(ABSPATH);
        $wp_content = realpath(WP_CONTENT_DIR);

        // Check if path is within WordPress directory
        return (strpos($real_path, $wp_root) === 0 || strpos($real_path, $wp_content) === 0);
    }

    /**
     * Sanitize log content
     *
     * @param string $content Log content to sanitize
     * @return string
     */
    private function sanitize_log_content($content) {
        // Remove sensitive information
        $patterns = array(
            '/(?:password|pwd|pass|secret|key)=\'[^\']*\'/',
            '/(?:password|pwd|pass|secret|key)="[^"]*"/',
            '/(?:password|pwd|pass|secret|key):\s*[^\s,\]})]+/'
        );
        
        foreach ($patterns as $pattern) {
            $content = preg_replace($pattern, '$1=\'REDACTED\'', $content);
        }
        
        // Remove file paths
        $replacements = array(
            ABSPATH => '[WORDPRESS_ROOT]/',
            WP_CONTENT_DIR => '[CONTENT_DIR]',
            str_replace('\\', '/', ABSPATH) => '[WORDPRESS_ROOT]/',
            str_replace('\\', '/', WP_CONTENT_DIR) => '[CONTENT_DIR]'
        );
        
        return str_replace(array_keys($replacements), array_values($replacements), $content);
    }

    /**
     * Render error log instructions
     */
    private function render_error_log_instructions() {
        ?>
        <div class="error-log-instructions">
            <h3><?php esc_html_e('How to Enable Error Logging', 'divewp'); ?></h3>
            
            <div class="notice notice-info inline">
                <p><?php esc_html_e('Error logging helps you identify and fix issues on your site. Here\'s how to enable it:', 'divewp'); ?></p>
            </div>

            <ol>
                <li>
                    <?php esc_html_e('Connect to your site via FTP or file manager', 'divewp'); ?>
                </li>
                <li>
                    <?php esc_html_e('Locate and edit wp-config.php in your WordPress root directory', 'divewp'); ?>
                </li>
                <li>
                    <?php esc_html_e('Add these lines before "/* That\'s all, stop editing! */":', 'divewp'); ?>
                    <pre><code><?php echo esc_html(
                        "// Enable WordPress debug logging\n" .
                        "define('WP_DEBUG', true);\n" .
                        "define('WP_DEBUG_LOG', true);\n" .
                        "define('WP_DEBUG_DISPLAY', false);"
                    ); ?></code></pre>
                </li>
                <li>
                    <?php esc_html_e('Save wp-config.php and refresh this page', 'divewp'); ?>
                </li>
            </ol>

            <div class="notice notice-warning">
                <p><strong><?php esc_html_e('Important:', 'divewp'); ?></strong></p>
                <ul>
                    <li><?php esc_html_e('Only enable debug logging temporarily on live sites', 'divewp'); ?></li>
                    <li><?php esc_html_e('Make sure debug.log is not publicly accessible', 'divewp'); ?></li>
                    <li><?php esc_html_e('Consider disabling logging after resolving issues', 'divewp'); ?></li>
                </ul>
            </div>

            <p>
                <em>
                    <?php 
                    printf(
                        /* translators: %s: Link to WordPress debugging documentation */
                        esc_html__('Need help? Check the %s.', 'divewp'),
                        '<a href="https://wordpress.org/documentation/article/debugging-in-wordpress/" target="_blank">' . 
                        esc_html__('WordPress Debugging Guide', 'divewp') . 
                        '</a>'
                    ); 
                    ?>
                </em>
            </p>
        </div>
        <?php
    }
}
