<?php
/**
 * Optimization Insights functionality for DiveWP
 *
 * This class provides performance optimization insights and recommendations.
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_Optimization_Insights {
    /**
     * Status constants
     */
    const STATUS_GOOD = 'success';
    const STATUS_WARNING = 'warning';
    const STATUS_CRITICAL = 'danger';
    const STATUS_INFO = 'info';

    /**
     * Get optimization insights data
     *
     * @since 1.0.0
     * @return array Array of optimization insights
     */
    public function get_optimization_data() {
        return array(
            'Popular Caching Plugin' => array(
                'value' => $this->check_caching(),
                'recommended' => __('Should be enabled', 'divewp'),
                'impact' => __('High', 'divewp')
            ),
            'Popular Minification Plugin' => array(
                'value' => $this->check_minification(),
                'recommended' => __('Should be enabled', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'Deferred JavaScript' => array(
                'value' => $this->check_deferred_js(),
                'recommended' => __('Should be enabled', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'Popular Image Optimization Plugin' => array(
                'value' => $this->check_image_optimization(),
                'recommended' => __('Should be installed', 'divewp'),
                'impact' => __('High', 'divewp')
            ),
            'Lazy Loading' => array(
                'value' => $this->check_lazy_loading(),
                'recommended' => __('Should be enabled', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
        );
    }

    /**
     * Get check thresholds and status mappings
     *
     * @since 1.0.0
     * @return array Check thresholds and status mappings
     */
    protected function get_check_thresholds() {
        return array(
            'status_map' => array(
                self::STATUS_GOOD => array(
                    'Detected',
                    'Enabled',
                    'Managed by plugin',
                    'Optimized'
                ),
                self::STATUS_WARNING => array(
                    'Managed by',
                    'Detected via',
                    'Partially configured'
                ),
                self::STATUS_CRITICAL => array(
                    'Not detected',
                    'Disabled',
                    'Not available'
                )
            )
        );
    }

    /**
     * Get status pill class based on value
     *
     * @since 1.0.0
     * @param string $key The setting key
     * @param string $value The current value
     * @return string The status pill class
     */
    public function get_pill_class($key, $value) {
        $thresholds = $this->get_check_thresholds();
        $status_map = $thresholds['status_map'];

        // Handle array values (like from check_compression)
        if (is_array($value)) {
            if ($key === 'Server Compression') {
                if (strpos($value['status'], 'Optimal') !== false) {
                    return 'status-pill-' . self::STATUS_GOOD;
                } elseif (strpos($value['status'], 'Alternative') !== false) {
                    return 'status-pill-' . self::STATUS_WARNING;
                }
                return 'status-pill-' . self::STATUS_CRITICAL;
            }
            // Use status field if available
            $value = isset($value['status']) ? $value['status'] : '';
        }

        // Check for exact matches in status map
        foreach ($status_map as $status => $phrases) {
            foreach ($phrases as $phrase) {
                if (strpos($value, $phrase) !== false) {
                    return 'status-pill-' . $status;
                }
            }
        }

        // Default to warning if no match found
        return 'status-pill-' . self::STATUS_WARNING;
    }

    /**
     * Check caching plugin status
     *
     * @since 1.0.0
     * @return string Status of caching
     */
    private function check_caching() {
        $caching_plugins = array(
            'wp-super-cache/wp-cache.php' => 'WP Super Cache',
            'w3-total-cache/w3-total-cache.php' => 'W3 Total Cache',
            'wp-fastest-cache/wpFastestCache.php' => 'WP Fastest Cache',
            'litespeed-cache/litespeed-cache.php' => 'LiteSpeed Cache',
            'wp-rocket/wp-rocket.php' => 'WP Rocket',
            'cache-enabler/cache-enabler.php' => 'Cache Enabler',
            'sg-cachepress/sg-cachepress.php' => 'SG Optimizer',
            'breeze/breeze.php' => 'Breeze',
            'swift-performance-lite/performance.php' => 'Swift Performance',
            'wp-optimize/wp-optimize.php' => 'WP-Optimize',
            'nitropack/main.php' => 'NitroPack',
            'flying-press/flying-press.php' => 'FlyingPress'
        );

        $detected_plugins = array();
        foreach ($caching_plugins as $plugin_path => $plugin_name) {
            if (is_plugin_active($plugin_path)) {
                $detected_plugins[] = $plugin_name;
            }
        }

        if (!empty($detected_plugins)) {
            return array(
                'status' => __('Detected', 'divewp'),
                'tooltip' => sprintf(
                    __('Active caching plugin(s): %s', 'divewp'),
                    implode(', ', $detected_plugins)
                )
            );
        }

        return array(
            'status' => __('Not detected', 'divewp'),
            'tooltip' => __('No caching plugin detected. Consider installing one for better performance.', 'divewp')
        );
    }

    /**
     * Check minification plugin status
     *
     * @since 1.0.0
     * @return string Status of minification
     */
    private function check_minification() {
        if (
            is_plugin_active('autoptimize/autoptimize.php') ||
            is_plugin_active('wp-rocket/wp-rocket.php') ||
            is_plugin_active('w3-total-cache/w3-total-cache.php') ||
            is_plugin_active('litespeed-cache/litespeed-cache.php') ||
            is_plugin_active('wp-fastest-cache/wpFastestCache.php') ||
            is_plugin_active('swift-performance-lite/performance.php') ||
            is_plugin_active('hummingbird-performance/wp-hummingbird.php') ||
            is_plugin_active('sg-cachepress/sg-cachepress.php')
        ) {
            return __('Detected via plugin', 'divewp');
        }
        
        return __('Not detected', 'divewp');
    }

    /**
     * Check deferred JavaScript status
     *
     * @since 1.0.0
     * @return string Status of deferred JavaScript
     */
    private function check_deferred_js() {
        if (
            is_plugin_active('wp-rocket/wp-rocket.php') ||
            is_plugin_active('flying-scripts/flying-scripts.php') ||
            is_plugin_active('async-javascript/async-javascript.php') ||
            is_plugin_active('autoptimize/autoptimize.php') ||
            is_plugin_active('sg-cachepress/sg-cachepress.php') ||
            is_plugin_active('w3-total-cache/w3-total-cache.php')
        ) {
            return __('Managed by plugin', 'divewp');
        }
        
        return __('Not detected', 'divewp');
    }

    /**
     * Check image optimization plugin status
     *
     * @since 1.0.0
     * @return string Status of image optimization
     */
    private function check_image_optimization() {
        if (
            is_plugin_active('webp-express/webp-express.php') ||
            is_plugin_active('imagify/imagify.php') ||
            is_plugin_active('wp-smushit/wp-smush.php') ||
            is_plugin_active('shortpixel-image-optimiser/wp-shortpixel.php') ||
            is_plugin_active('ewww-image-optimizer/ewww-image-optimizer.php') ||
            is_plugin_active('optimus/optimus.php') ||
            is_plugin_active('tiny-compress-images/tiny-compress-images.php') ||
            is_plugin_active('compress-jpeg-png-images/compress-jpeg-png-images.php') ||
            is_plugin_active('wp-compress/wp-compress.php') ||
            is_plugin_active('imagerecycle-pdf-image-compression/wp-image-recycle.php')
        ) {
            return __('Detected', 'divewp');
        }

        return __('Not detected', 'divewp');
    }

    /**
     * Check lazy loading status
     *
     * @since 1.0.0
     * @return string Status of lazy loading
     */
    private function check_lazy_loading() {
        if (
            is_plugin_active('a3-lazy-load/a3-lazy-load.php') ||
            is_plugin_active('rocket-lazy-load/rocket-lazy-load.php') ||
            is_plugin_active('wp-rocket/wp-rocket.php') ||
            is_plugin_active('autoptimize/autoptimize.php') ||
            is_plugin_active('sg-cachepress/sg-cachepress.php') ||
            is_plugin_active('flying-press/flying-press.php') ||
            is_plugin_active('ewww-image-optimizer/ewww-image-optimizer.php') ||
            is_plugin_active('ewww-image-optimizer-cloud/ewww-image-optimizer-cloud.php')
        ) {
            return __('Detected via plugin', 'divewp');
        }

        return __('Not detected', 'divewp');
    }

    /**
     * Render optimization data
     *
     * @since 1.0.0
     * @param array $optimization_data Optimization data to render
     * @return void
     */
    public function render_optimization_data($optimization_data) {
        if (empty($optimization_data)) {
            echo '<p>' . esc_html__('No optimization data available.', 'divewp') . '</p>';
            return;
        }

        echo '<h3>' . esc_html__('Performance Optimization Insights', 'divewp') . '</h3>';
        echo '<table class="divewp-table">';
        echo '<tr><th>' . esc_html__('Check', 'divewp') . '</th><th>' . esc_html__('Current Value', 'divewp') . '</th><th>' . esc_html__('Recommended', 'divewp') . '</th><th>' . esc_html__('Performance Impact', 'divewp') . '</th></tr>';
        
        foreach ($optimization_data as $key => $data) {
            $value = is_array($data['value']) ? $data['value']['status'] : $data['value'];
            $tooltip = is_array($data['value']) ? $data['value']['tooltip'] : '';
            
            echo '<tr>';
            echo '<td><strong>' . esc_html__($key, 'divewp') . '</strong></td>';
            echo '<td><span class="status-pill ' . esc_attr($this->get_pill_class($key, $data['value'])) . '"' . 
                 ($tooltip ? ' data-tooltip="' . esc_attr($tooltip) . '"' : '') . '>' . 
                 esc_html($value) . '</span></td>';
            echo '<td>' . esc_html($data['recommended']) . '</td>';
            echo '<td>' . esc_html($data['impact']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';

        echo '<div class="optimization-recommendations no-print">';
        $this->render_optimization_recommendations();
        echo '</div>';
    }

    /**
     * Render optimization recommendations
     *
     * @since 1.0.0
     * @return void
     */
    private function render_optimization_recommendations() {
        echo '<h3>' . esc_html__('Optimization Recommendations', 'divewp') . '</h3>';
        echo '<ul>';
        
        // Caching
        echo '<li><strong>' . esc_html__('Caching:', 'divewp') . '</strong> ';
        echo esc_html__('Caching creates static versions of your dynamic content, significantly reducing server load and improving load times. Consider using:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . esc_html__('Page caching for static content', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Browser caching for returning visitors', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Object caching for database queries', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';
        
        // Image Optimization
        echo '<li><strong>' . esc_html__('Image Optimization:', 'divewp') . '</strong> ';
        echo esc_html__('Optimize your images to reduce file sizes without compromising quality:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . esc_html__('Install a reliable image optimization plugin', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Consider using WebP format for better compression', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Resize images to their display size before upload', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Enable lazy loading for better page load times', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';
        
        // Code Optimization
        echo '<li><strong>' . esc_html__('Code Optimization:', 'divewp') . '</strong> ';
        echo esc_html__('Optimize your code delivery to improve loading speed:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . esc_html__('Minify CSS, JavaScript, and HTML', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Combine files to reduce HTTP requests', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Use GZIP compression', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';
        
        // Server-side Optimization
        echo '<li><strong>' . esc_html__('Server Configuration:', 'divewp') . '</strong> ';
        echo esc_html__('Proper server configuration is crucial for optimal performance:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . esc_html__('Enable PHP OPcache for bytecode caching', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Use latest PHP version for better performance', 'divewp') . '</li>';
        echo '<li>' . esc_html__('Consider using a CDN for global reach', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';

        // Update compression recommendations
        echo '<li><strong>' . __('Server Compression:', 'divewp') . '</strong> ';
        echo __('Optimize content delivery with proper compression:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Enable GZIP compression through your hosting provider or server configuration', 'divewp') . '</li>';
        echo '<li>' . __('Consider using a CDN that provides automatic compression', 'divewp') . '</li>';
        echo '<li>' . __('Verify compression is working using online testing tools', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';

        echo '</ul>';

        // Add warning box
        echo '<div class="divewp-notice divewp-notice-warning">';
        echo '<p><strong>' . esc_html__('Important:', 'divewp') . '</strong> ';
        echo esc_html__('Test your site after implementing performance optimizations. Some optimizations might conflict with certain plugins or themes. Always keep backups before making significant changes.', 'divewp');
        echo '</p>';
        echo '</div>';
    }
}
