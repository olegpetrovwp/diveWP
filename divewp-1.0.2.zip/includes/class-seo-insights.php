<?php
/**
 * SEO Insights functionality for DiveWP
 *
 * @package DiveWP
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_SEO_Insights {
    /**
     * Status constants
     */
    const STATUS_GOOD = 'success';
    const STATUS_WARNING = 'warning';
    const STATUS_CRITICAL = 'danger';
    const STATUS_INFO = 'info';

    /**
     * Get SEO insights data
     *
     * @since 1.0.0
     * @return array Array of SEO insights
     */
    public function get_seo_data() {
        return array(
            'SEO Plugin' => array(
                'value' => $this->detect_seo_plugin(),
                'recommended' => __('Should have a dedicated SEO plugin', 'divewp'),
                'impact' => __('High', 'divewp')
            ),
            'Permalink Structure' => array(
                'value' => $this->get_permalink_structure(),
                'recommended' => __('Should be SEO friendly', 'divewp'),
                'impact' => __('High', 'divewp')
            ),
            'Search Engine Visibility' => array(
                'value' => $this->check_search_visibility(),
                'recommended' => __('Should be visible to search engines', 'divewp'),
                'impact' => __('Critical', 'divewp')
            ),
            'XML Sitemap' => array(
                'value' => $this->check_sitemap_availability(),
                'recommended' => __('Should be available', 'divewp'),
                'impact' => __('High', 'divewp')
            )
        );
    }

    /**
     * Get check thresholds
     *
     * @since 1.0.0
     * @return array Check thresholds and status mappings
     */
    protected function get_check_thresholds() {
        return array(
            'status_map' => array(
                self::STATUS_GOOD => array(
                    'Yoast SEO',
                    'Rank Math',
                    'All in One SEO Pack',
                    'SEO Framework',
                    'SEOPress',
                    'SEO Friendly',
                    'Visible',
                    'Available'
                ),
                self::STATUS_WARNING => array(
                    'Custom Structure',
                    'WordPress default sitemap',
                    'Managed by'
                ),
                self::STATUS_CRITICAL => array(
                    'No SEO plugin detected',
                    'Plain (Not SEO Friendly)',
                    'Hidden',
                    'Not available',
                    'No sitemap detected'
                )
            )
        );
    }

    /**
     * Get status pill class
     *
     * @since 1.0.0
     * @param string $key The setting key
     * @param mixed $value The current value
     * @return string The status pill class
     */
    public function get_pill_class($key, $value) {
        $thresholds = $this->get_check_thresholds();
        
        // Handle array values
        if (is_array($value)) {
            $value = $value['status'];
        }

        // Check status map for text-based statuses
        foreach ($thresholds['status_map'] as $status => $phrases) {
            foreach ($phrases as $phrase) {
                if (strpos($value, $phrase) !== false) {
                    return 'status-pill-' . $status;
                }
            }
        }

        // Default to warning if no match found
        return 'status-pill-' . self::STATUS_WARNING;
    }

    /**
     * Detect active SEO plugin
     *
     * @since 1.0.0
     * @return string Active SEO plugin name or status
     */
    private function detect_seo_plugin() {
        if (is_plugin_active('wordpress-seo/wp-seo.php')) {
            return __('Yoast SEO', 'divewp');
        }
        if (is_plugin_active('seo-by-rank-math/rank-math.php')) {
            return __('Rank Math', 'divewp');
        }
        if (is_plugin_active('all-in-one-seo-pack/all_in_one_seo_pack.php')) {
            return __('All in One SEO Pack', 'divewp');
        }
        if (is_plugin_active('autodescription/autodescription.php')) {
            return __('SEO Framework', 'divewp');
        }
        if (is_plugin_active('wp-seopress/seopress.php')) {
            return __('SEOPress', 'divewp');
        }
        return __('No SEO plugin detected', 'divewp');
    }

    /**
     * Get permalink structure status
     *
     * @since 1.0.0
     * @return string Permalink structure status
     */
    private function get_permalink_structure() {
        $structure = get_option('permalink_structure');
        
        if (empty($structure)) {
            return __('Plain (Not SEO Friendly)', 'divewp');
        }
        
        if (strpos($structure, '%postname%') !== false) {
            return __('SEO Friendly', 'divewp');
        }
        
        return __('Custom Structure', 'divewp');
    }

    /**
     * Check search engine visibility
     *
     * @since 1.0.0
     * @return string Search engine visibility status
     */
    private function check_search_visibility() {
        return get_option('blog_public') ? 
            __('Visible', 'divewp') : 
            __('Hidden - Search engines discouraged', 'divewp');
    }

    /**
     * Check sitemap availability
     *
     * @since 1.0.0
     * @return array|string Sitemap availability status and tooltip
     */
    private function check_sitemap_availability() {
        $active_plugin = $this->detect_seo_plugin();
        
        if ($active_plugin === __('No SEO plugin detected', 'divewp')) {
            if (get_option('permalink_structure')) {
                return array(
                    'status' => __('WordPress default sitemap', 'divewp'),
                    'tooltip' => __('Default WordPress sitemap lacks advanced features like custom post types and image sitemaps. Installing a dedicated SEO plugin is recommended for better search engine optimization.', 'divewp')
                );
            }
            return array(
                'status' => __('No sitemap detected', 'divewp'),
                'tooltip' => __('No sitemap found. Consider enabling permalinks or installing an SEO plugin.', 'divewp')
            );
        }
        
        return array(
            'status' => sprintf(__('Managed by %s', 'divewp'), $active_plugin),
            'tooltip' => sprintf(__('Sitemap is being managed by %s. Check plugin settings for customization options.', 'divewp'), $active_plugin)
        );
    }

    /**
     * Render SEO data
     *
     * @since 1.0.0
     * @param array $seo_data SEO data to render
     * @return void
     */
    public function render_seo_data($seo_data) {
        if (empty($seo_data)) {
            echo '<p>' . esc_html__('No SEO data available.', 'divewp') . '</p>';
            return;
        }

        echo '<h3>' . esc_html__('SEO Status', 'divewp') . '</h3>';
        echo '<table class="divewp-table">';
        echo '<tr><th>' . esc_html__('Check', 'divewp') . '</th><th>' . esc_html__('Status', 'divewp') . '</th><th>' . esc_html__('Recommended', 'divewp') . '</th><th>' . esc_html__('Impact', 'divewp') . '</th></tr>';
        
        foreach ($seo_data as $key => $data) {
            $value = is_array($data['value']) ? $data['value']['status'] : $data['value'];
            $tooltip = is_array($data['value']) && isset($data['value']['tooltip']) ? $data['value']['tooltip'] : '';
            
            echo '<tr>';
            echo '<td><strong>' . esc_html__($key, 'divewp') . '</strong></td>';
            echo '<td><span class="status-pill ' . esc_attr($this->get_pill_class($key, $data['value'])) . '"' . 
                 ($tooltip ? ' data-tooltip="' . esc_attr($tooltip) . '"' : '') . '>' . 
                 esc_html($value) . '</span></td>';
            echo '<td>' . esc_html($data['recommended']) . '</td>';
            echo '<td>' . esc_html($data['impact']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';

        $this->render_seo_recommendations($seo_data['SEO Plugin']['value']);
    }

    /**
     * Render SEO recommendations
     */
    private function render_seo_recommendations($active_plugin) {
        echo '<div class="seo-recommendations">';
        echo '<h3>' . __('SEO Recommendations', 'divewp') . '</h3>';
        
        if ($active_plugin === __('No SEO plugin detected', 'divewp')) {
            $this->render_no_plugin_recommendations();
        } else {
            $this->render_plugin_specific_recommendations($active_plugin);
        }
        
        echo '</div>';
    }

    private function render_no_plugin_recommendations() {
        echo '<div class="notice notice-warning inline"><p>';
        echo __('No SEO plugin detected. We recommend installing one of these popular SEO plugins:', 'divewp');
        echo '</p></div>';
        
        echo '<ul>';
        echo '<li><strong>Yoast SEO:</strong> ' . __('Most popular choice with comprehensive features', 'divewp') . '</li>';
        echo '<li><strong>Rank Math:</strong> ' . __('Modern alternative with growing popularity', 'divewp') . '</li>';
        echo '<li><strong>All in One SEO Pack:</strong> ' . __('Established plugin with easy setup', 'divewp') . '</li>';
        echo '</ul>';

        echo '<div class="seo-important-notice">';
        echo '<h4>' . __('Why You Need an SEO Plugin', 'divewp') . '</h4>';
        echo '<ul>';
        echo '<li>' . __('Helps search engines better understand your content', 'divewp') . '</li>';
        echo '<li>' . __('Provides tools to optimize your content for better rankings', 'divewp') . '</li>';
        echo '<li>' . __('Generates XML sitemaps automatically', 'divewp') . '</li>';
        echo '<li>' . __('Manages meta titles and descriptions', 'divewp') . '</li>';
        echo '<li>' . __('Handles social media integration', 'divewp') . '</li>';
        echo '<li>' . __('Provides content analysis and suggestions', 'divewp') . '</li>';
        echo '</ul>';

        echo '<h4>' . __('Basic SEO Steps Without a Plugin', 'divewp') . '</h4>';
        echo '<ul>';
        echo '<li>' . __('Use SEO-friendly permalinks (already set to: ', 'divewp') . esc_html($this->get_permalink_structure()) . ')</li>';
        echo '<li>' . __('Write descriptive titles for your pages and posts', 'divewp') . '</li>';
        echo '<li>' . __('Use heading tags (H1, H2, H3) properly', 'divewp') . '</li>';
        echo '<li>' . __('Optimize your images with descriptive names and alt tags', 'divewp') . '</li>';
        echo '<li>' . __('Create quality content that provides value to users', 'divewp') . '</li>';
        echo '<li>' . __('Ensure your site loads quickly and works well on mobile devices', 'divewp') . '</li>';
        echo '</ul>';
        echo '</div>';
    }

    private function render_plugin_specific_recommendations($plugin) {
        echo '<p>' . sprintf(__('Your site is using %s. Here\'s what you should check:', 'divewp'), $plugin) . '</p>';
        
        echo '<div class="seo-important-notice">';
        echo '<h4>' . __('Essential Setup Steps', 'divewp') . '</h4>';
        echo '<ul>';
        echo '<li>' . __('Complete the plugin\'s setup wizard if you haven\'t already', 'divewp') . '</li>';
        echo '<li>' . __('Configure your sitemap settings and submit to search engines', 'divewp') . '</li>';
        echo '<li>' . __('Set up social media integration for better sharing', 'divewp') . '</li>';
        echo '<li>' . __('Review and optimize your homepage meta data', 'divewp') . '</li>';
        echo '</ul>';

        echo '<h4>' . __('Regular SEO Maintenance', 'divewp') . '</h4>';
        echo '<ul>';
        echo '<li>' . __('Regularly review and update your focus keywords', 'divewp') . '</li>';
        echo '<li>' . __('Check for and fix any SEO errors or warnings', 'divewp') . '</li>';
        echo '<li>' . __('Monitor your content\'s SEO scores and improve where needed', 'divewp') . '</li>';
        echo '<li>' . __('Keep your SEO plugin updated to the latest version', 'divewp') . '</li>';
        echo '</ul>';

        echo '<h4>' . __('Advanced Optimization', 'divewp') . '</h4>';
        echo '<ul>';
        echo '<li>' . __('Implement schema markup for rich snippets', 'divewp') . '</li>';
        echo '<li>' . __('Set up breadcrumbs for better site structure', 'divewp') . '</li>';
        echo '<li>' . __('Configure advanced robots.txt rules if needed', 'divewp') . '</li>';
        echo '<li>' . __('Use content analysis tools for optimization', 'divewp') . '</li>';
        echo '</ul>';

        echo '<div class="notice notice-info inline" style="margin-top: 15px;">';
        echo '<p><strong>' . __('Pro Tip:', 'divewp') . '</strong> ';
        echo __('Consider connecting your site to Google Search Console and Google Analytics for better SEO insights and performance tracking.', 'divewp');
        echo '</p>';
        echo '</div>';
        echo '</div>';
    }
}
