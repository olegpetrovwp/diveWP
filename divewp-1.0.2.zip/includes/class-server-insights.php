<?php
/**
 * Server Insights functionality for DiveWP
 *
 * This class provides server-related insights and recommendations.
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_Server_Insights {
    /**
     * Status constants
     */
    const STATUS_GOOD = 'success';
    const STATUS_WARNING = 'warning';
    const STATUS_CRITICAL = 'danger';
    const STATUS_INFO = 'info';

    /**
     * Get server insights data
     *
     * @since 1.0.0
     * @return array Array of server insights
     */
    public function get_server_data() {
        $server_data = array(
            'PHP Version' => array(
                'value' => PHP_VERSION,
                'recommended' => __('8.2 or higher', 'divewp'),
                'impact' => __('High', 'divewp')
            ),
            'MySQL Version' => array(
                'value' => $this->get_mysql_version(),
                'recommended' => __('5.6 or higher', 'divewp'),
                'impact' => __('High', 'divewp')
            ),
            'Memory Limit' => array(
                'value' => ini_get('memory_limit'),
                'recommended' => __('256M or higher', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'Max Execution Time' => array(
                'value' => ini_get('max_execution_time') . 's',
                'recommended' => __('30s or higher', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'Post Max Size' => array(
                'value' => ini_get('post_max_size'),
                'recommended' => __('64M or higher', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'Upload Max Size' => array(
                'value' => ini_get('upload_max_filesize'),
                'recommended' => __('32M or higher', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'Max Input Vars' => array(
                'value' => ini_get('max_input_vars'),
                'recommended' => __('3000 or higher', 'divewp'),
                'impact' => __('Medium', 'divewp')
            )
        );
        
        return apply_filters('divewp_server_insights_data', $server_data);
    }

    /**
     * Get MySQL version
     *
     * @since 1.0.0
     * @return string MySQL version
     */
    private function get_mysql_version() {
        global $wpdb;
        return $wpdb->db_version();
    }

    /**
     * Get check thresholds
     *
     * @since 1.0.0
     * @return array Check thresholds
     */
    protected function get_check_thresholds() {
        return array(
            'PHP Version' => array(
                'optimal' => '8.0',
                'warning' => '7.4'
            ),
            'MySQL Version' => array(
                'optimal' => '5.7',
                'warning' => '5.6'
            ),
            'Memory Limit' => array(
                'optimal' => 256,
                'warning' => 128
            ),
            'Max Execution Time' => array(
                'optimal' => 60,
                'warning' => 30
            ),
            'Post Max Size' => array(
                'optimal' => 64,
                'warning' => 32
            ),
            'Upload Max Size' => array(
                'optimal' => 32,
                'warning' => 16
            ),
            'Max Input Vars' => array(
                'optimal' => 3000,
                'warning' => 1000
            )
        );
    }

    /**
     * Normalize value for comparison
     *
     * @since 1.0.0
     * @param mixed $value The value to normalize
     * @return mixed Normalized value
     */
    protected function normalize_value($value) {
        // Remove 'M' from memory values and convert to integer
        if (strpos($value, 'M') !== false) {
            return (int)$value;
        }
        
        // Remove 's' from time values
        if (strpos($value, 's') !== false) {
            return (int)$value;
        }
        
        return $value;
    }

    /**
     * Get status pill class
     *
     * @since 1.0.0
     * @param string $key The setting key
     * @param mixed $value The current value
     * @return string The status pill class
     */
    public function get_pill_class($key, $value) {
        $thresholds = $this->get_check_thresholds();
        
        if (!isset($thresholds[$key])) {
            return 'status-pill-' . self::STATUS_INFO;
        }

        $normalized_value = $this->normalize_value($value);
        
        if ($key === 'PHP Version' || $key === 'MySQL Version') {
            if (version_compare($normalized_value, $thresholds[$key]['optimal'], '>=')) {
                return 'status-pill-' . self::STATUS_GOOD;
            } elseif (version_compare($normalized_value, $thresholds[$key]['warning'], '>=')) {
                return 'status-pill-' . self::STATUS_WARNING;
            }
            return 'status-pill-' . self::STATUS_CRITICAL;
        }
        
        // For numeric values
        $numeric_value = (int)$normalized_value;
        if ($numeric_value >= $thresholds[$key]['optimal']) {
            return 'status-pill-' . self::STATUS_GOOD;
        } elseif ($numeric_value >= $thresholds[$key]['warning']) {
            return 'status-pill-' . self::STATUS_WARNING;
        }
        return 'status-pill-' . self::STATUS_CRITICAL;
    }

    /**
     * Render server data
     *
     * @since 1.0.0
     * @param array $server_data Server data to render
     * @return void
     */
    public function render_server_data($server_data) {
        if (empty($server_data)) {
            echo '<p>' . esc_html__('No server data available.', 'divewp') . '</p>';
            return;
        }

        echo '<h3>' . esc_html__('Server Insights', 'divewp') . '</h3>';
        echo '<table class="divewp-table">';
        echo '<tr><th>' . esc_html__('Setting', 'divewp') . '</th><th>' . esc_html__('Current Value', 'divewp') . '</th><th>' . esc_html__('Recommended', 'divewp') . '</th><th>' . esc_html__('Performance Impact', 'divewp') . '</th></tr>';
        
        foreach ($server_data as $key => $data) {
            echo '<tr>';
            echo '<td><strong>' . esc_html__($key, 'divewp') . '</strong></td>';
            echo '<td><span class="status-pill ' . esc_attr($this->get_pill_class($key, $data['value'])) . '">' . esc_html($data['value']) . '</span></td>';
            echo '<td>' . esc_html($data['recommended']) . '</td>';
            echo '<td>' . esc_html($data['impact']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';

        echo '<div class="server-recommendations no-print">';
        $this->render_server_recommendations();
        echo '</div>';
    }

    /**
     * Renders server recommendations
     *
     * @since 1.0.0
     * @return void
     */
    private function render_server_recommendations() {
        echo '<h3>' . __('Server Recommendations', 'divewp') . '</h3>';
        echo '<ul>';
        
        // PHP Configuration
        echo '<li><strong>' . __('PHP Configuration:', 'divewp') . '</strong> ';
        echo __('PHP settings significantly impact your site\'s performance and functionality:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Keep PHP version updated for security and performance', 'divewp') . '</li>';
        echo '<li>' . __('Increase memory limits if you handle large media files', 'divewp') . '</li>';
        echo '<li>' . __('Adjust max execution time for complex operations', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';
        
        // Database Configuration
        echo '<li><strong>' . __('Database Setup:', 'divewp') . '</strong> ';
        echo __('Your database configuration affects site speed and reliability:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Use latest MySQL/MariaDB version for better performance', 'divewp') . '</li>';
        echo '<li>' . __('Enable query caching if available', 'divewp') . '</li>';
        echo '<li>' . __('Regular backups are essential', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';
        
        // WordPress Configuration
        echo '<li><strong>' . __('WordPress Settings:', 'divewp') . '</strong> ';
        echo __('Optimize WordPress configuration for your server environment:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Adjust WordPress memory limit in wp-config.php', 'divewp') . '</li>';
        echo '<li>' . __('Configure WP_DEBUG appropriately for your environment', 'divewp') . '</li>';
        echo '<li>' . __('Enable WP Cron only if server cron is not available', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';
        
        // Server Environment
        echo '<li><strong>' . __('Server Environment:', 'divewp') . '</strong> ';
        echo __('Your hosting environment should match your site\'s needs:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Choose appropriate hosting type (shared, VPS, dedicated)', 'divewp') . '</li>';
        echo '<li>' . __('Monitor server resource usage', 'divewp') . '</li>';
        echo '<li>' . __('Use SSL for security and SEO benefits', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';

        echo '</ul>';

        // Add warning box
        echo '<div style="margin-top: 20px; padding: 15px; background-color: #fef8ee; border-left: 4px solid #ffb900;">';
        echo '<p style="margin: 0;"><strong>' . __('Important:', 'divewp') . '</strong> ';
        echo __('Server configuration changes should be made carefully. Incorrect settings can make your site inaccessible. Always backup before making changes and consult your hosting provider if unsure.', 'divewp');
        echo '</p>';
        echo '</div>';
    }

    public function get_server_technology() {
        $sapi_type = php_sapi_name();
        $technology = 'Unknown';
        $color = 'status-pill-info';
        $tooltip = __('With proper configuration, this server technology can perform optimally.', 'divewp');

        if (stripos($sapi_type, 'litespeed') !== false) {
            $technology = 'LiteSpeed';
            $tooltip = __('LiteSpeed is optimized for WordPress and offers excellent performance.', 'divewp');
        } elseif (stripos($sapi_type, 'cgi-fcgi') !== false) {
            $technology = 'FastCGI';
            $tooltip = __('FastCGI is efficient and often used with Nginx.', 'divewp');
        } elseif (stripos($sapi_type, 'apache2handler') !== false) {
            $technology = 'Apache';
            $tooltip = __('Apache is widely used and flexible, but may need tuning for optimal performance.', 'divewp');
        } elseif (stripos($sapi_type, 'fpm-fcgi') !== false) {
            $technology = 'PHP-FPM';
            $tooltip = __('PHP-FPM is a FastCGI Process Manager, often used with Nginx for better performance.', 'divewp');
        }

        return array('technology' => $technology, 'color' => $color, 'tooltip' => $tooltip);
    }
}
