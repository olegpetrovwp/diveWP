<?php
/**
 * Plugin Name: DiveWP
 * Plugin URI: https://divewp.com
 * Description: Dive deep into your WordPress site with comprehensive insights on your server, performance/speed, security, WooCommerce, and SEO.
 * Version: 1.0.3
 * Requires at least: 5.3.18
 * Requires PHP: 7.0.33
 * Author: Oleg Petrov
 * Author URI: https://oleg-petrov.com
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: divewp
 * Domain Path: /languages
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

// Add this check and include
if (!function_exists('is_plugin_active')) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

// Check PHP Version
if (version_compare(PHP_VERSION, '7.4', '<')) {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p>' . 
             sprintf(
                 /* translators: %s: PHP version */
                 esc_html__('DiveWP requires PHP version %s or higher.', 'divewp'),
                 '7.4'
             ) . 
             '</p></div>';
    });
    return;
}

// Define plugin constants
define('DIVEWP_VERSION', '1.0.3');
define('DIVEWP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('DIVEWP_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once DIVEWP_PLUGIN_DIR . 'includes/class-divewp-main.php';
require_once DIVEWP_PLUGIN_DIR . 'includes/class-email-logger.php';
require_once DIVEWP_PLUGIN_DIR . 'includes/class-dashboard-overview.php';
require_once DIVEWP_PLUGIN_DIR . 'includes/class-update-checker.php';

// Initialize the plugin
function divewp_run_plugin() {
    $plugin = new DiveWP_Main();
    $plugin->run();
}
add_action('plugins_loaded', 'divewp_run_plugin');

// Initialize update checker separately on init hook
function divewp_init_update_checker() {
    new DiveWP_Update_Checker();
}
add_action('init', 'divewp_init_update_checker');

// Register activation hook
register_activation_hook(__FILE__, 'divewp_activate');

// Register deactivation hook
register_deactivation_hook(__FILE__, 'divewp_deactivate');

// Activation function
function divewp_activate() {
    // Start output buffering
    ob_start();

    try {
        global $wpdb;
        
        // Create tables
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        
        $charset_collate = $wpdb->get_charset_collate();
        $table_name = $wpdb->prefix . 'divewp_email_log';
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            date_sent datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status varchar(20) NOT NULL,
            initiator text NOT NULL,
            from_email varchar(100) NOT NULL,
            to_email varchar(100) NOT NULL,
            subject varchar(255) NOT NULL,
            error_msg text DEFAULT NULL,
            PRIMARY KEY (id),
            KEY date_sent (date_sent),
            KEY status (status)
        ) $charset_collate;";
        
        dbDelta($sql);
        
        // Any other activation tasks
        flush_rewrite_rules();
        
    } catch (Exception $e) {
        // Log the error
        error_log(__('DiveWP Activation Error: ', 'divewp') . $e->getMessage());
    }

    // Clean the output buffer and discard its contents
    ob_end_clean();
}

// Deactivation function
function divewp_deactivate() {
    // Clear scheduled events
    wp_clear_scheduled_hook('divewp_daily_cleanup');
    
    // Flush rewrite rules
    flush_rewrite_rules();
}

// Load plugin text domain
function divewp_load_textdomain() {
    load_plugin_textdomain('divewp', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'divewp_load_textdomain');
