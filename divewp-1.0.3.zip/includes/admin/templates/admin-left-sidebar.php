<?php
/**
 * Admin Left Sidebar Template
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */
?>
<div class="divewp-tabs-column">
    <div class="divewp-logo-container">
        <img src="<?php echo DIVEWP_PLUGIN_URL; ?>assets/images/divewp-logo.png" 
             alt="<?php echo esc_attr__('DiveWP', 'divewp'); ?>" 
             class="divewp-logo"
        >
    </div>
    <ul class="divewp-tabs">
        <li data-tab="welcome" class="active"><?php _e('Dashboard', 'divewp'); ?></li>
        <li data-tab="server"><?php _e('PHP Server Insights', 'divewp'); ?></li>
        <li data-tab="optimization"><?php _e('Performance Optimizations', 'divewp'); ?></li>
        <li data-tab="database"><?php _e('Database Insights', 'divewp'); ?></li>
        <li data-tab="security"><?php _e('Security Insights', 'divewp'); ?></li>
        <li data-tab="woocommerce"><?php _e('WooCommerce Insights', 'divewp'); ?></li>
        <li data-tab="seo"><?php _e('SEO Insights', 'divewp'); ?></li>
        <li data-tab="email"><?php _e('Email Communications', 'divewp'); ?></li>
        <li data-tab="error-logs"><?php _e('Error Logs', 'divewp'); ?></li>
    </ul>
</div>
