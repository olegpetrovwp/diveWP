<?php
/**
 * Dashboard Overview functionality for DiveWP
 *
 * @package DiveWP
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_Dashboard_Overview {
    private $insights_data = [];

    public function __construct() {
        $this->collect_all_insights();
    }

    private function collect_all_insights() {
        // Get instances of all insight classes
        $server_insights = new DiveWP_Server_Insights();
        $optimization_insights = new DiveWP_Optimization_Insights();
        $security_insights = new DiveWP_Security_Insights();
        $database_insights = new DiveWP_Database_Insights();
        $seo_insights = new DiveWP_SEO_Insights();
        $woocommerce_insights = new DiveWP_WooCommerce_Insights();
        $email_insights = new DiveWP_Email_Insights();

        // Collect all insights
        $this->insights_data = [
            'server' => [
                'name' => __('Server Insights', 'divewp'),
                'data' => $server_insights->get_server_data(),
                'instance' => $server_insights
            ],
            'optimization' => [
                'name' => __('Performance', 'divewp'),
                'data' => $optimization_insights->get_optimization_data(),
                'instance' => $optimization_insights
            ],
            'security' => [
                'name' => __('Security', 'divewp'),
                'data' => $security_insights->get_security_data(),
                'instance' => $security_insights
            ],
            'database' => [
                'name' => __('Database', 'divewp'),
                'data' => $database_insights->get_database_data(),
                'instance' => $database_insights
            ],
            'seo' => [
                'name' => __('SEO', 'divewp'),
                'data' => $seo_insights->get_seo_data(),
                'instance' => $seo_insights
            ],
            'email' => [
                'name' => __('Email', 'divewp'),
                'data' => $email_insights->get_email_data(),
                'instance' => $email_insights
            ]
        ];

        // Only add WooCommerce insights if WooCommerce is active and has data
        $woo_data = $woocommerce_insights->get_woocommerce_data();
        if (!empty($woo_data)) {
            $this->insights_data['woocommerce'] = [
                'name' => __('WooCommerce', 'divewp'),
                'data' => $woo_data,
                'instance' => $woocommerce_insights
            ];
        }
    }

    private function count_status_pills() {
        $counts = [
            'success' => [],
            'warning' => [],
            'danger' => []
        ];

        foreach ($this->insights_data as $tab_id => $insight) {
            $success_count = 0;
            $warning_count = 0;
            $danger_count = 0;

            foreach ($insight['data'] as $check => $data) {
                $pill_class = $insight['instance']->get_pill_class($check, $data['value']);
                
                if ($pill_class === 'status-pill-success') {
                    $success_count++;
                } elseif ($pill_class === 'status-pill-warning') {
                    $warning_count++;
                } elseif ($pill_class === 'status-pill-danger') {
                    $danger_count++;
                }
            }

            if ($success_count > 0) {
                $counts['success'][$tab_id] = [
                    'name' => $insight['name'],
                    'count' => $success_count
                ];
            }
            if ($warning_count > 0) {
                $counts['warning'][$tab_id] = [
                    'name' => $insight['name'],
                    'count' => $warning_count
                ];
            }
            if ($danger_count > 0) {
                $counts['danger'][$tab_id] = [
                    'name' => $insight['name'],
                    'count' => $danger_count
                ];
            }
        }

        return $counts;
    }

    public function render_overview_cards() {
        $counts = $this->count_status_pills();
        ?>
        <div class="divewp-dashboard-grid">
            <!-- Success Card -->
            <div class="divewp-card divewp-card-success">
                <div class="divewp-card-header">
                    <h3><?php _e('Optimal', 'divewp'); ?></h3>
                    <span class="divewp-card-count"><?php echo array_sum(array_column($counts['success'], 'count')); ?></span>
                </div>
                <div class="divewp-card-body">
                    <ul class="divewp-status-list">
                        <?php foreach ($counts['success'] as $tab_id => $data): ?>
                            <li>
                                <?php 
                                $items = array();
                                foreach ($this->insights_data[$tab_id]['data'] as $key => $item) {
                                    $value = is_array($item['value']) ? $item['value']['status'] : $item['value'];
                                    if (strpos($this->insights_data[$tab_id]['instance']->get_pill_class($key, $value), 'status-pill-success') !== false) {
                                        $items[] = $key;
                                    }
                                }
                                ?>
                                <a href="javascript:void(0);" class="divewp-tab-link" data-tab="<?php echo esc_attr($tab_id); ?>" data-tooltip="<?php echo esc_attr(implode(', ', $items)); ?>">
                                    <?php echo esc_html($data['name']); ?>
                                    <span class="divewp-count-badge"><?php echo esc_html($data['count']); ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <!-- Warning Card -->
            <div class="divewp-card divewp-card-warning">
                <div class="divewp-card-header">
                    <h3><?php _e('Warnings', 'divewp'); ?></h3>
                    <span class="divewp-card-count"><?php echo array_sum(array_column($counts['warning'], 'count')); ?></span>
                </div>
                <div class="divewp-card-body">
                    <ul class="divewp-status-list">
                        <?php foreach ($counts['warning'] as $tab_id => $data): ?>
                            <li>
                                <?php 
                                $items = array();
                                foreach ($this->insights_data[$tab_id]['data'] as $key => $item) {
                                    $value = is_array($item['value']) ? $item['value']['status'] : $item['value'];
                                    if (strpos($this->insights_data[$tab_id]['instance']->get_pill_class($key, $value), 'status-pill-warning') !== false) {
                                        $items[] = $key;
                                    }
                                }
                                ?>
                                <a href="javascript:void(0);" class="divewp-tab-link" data-tab="<?php echo esc_attr($tab_id); ?>" data-tooltip="<?php echo esc_attr(implode(', ', $items)); ?>">
                                    <?php echo esc_html($data['name']); ?>
                                    <span class="divewp-count-badge"><?php echo esc_html($data['count']); ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <!-- Danger Card -->
            <div class="divewp-card divewp-card-danger">
                <div class="divewp-card-header">
                    <h3><?php _e('Critical', 'divewp'); ?></h3>
                    <span class="divewp-card-count"><?php echo array_sum(array_column($counts['danger'], 'count')); ?></span>
                </div>
                <div class="divewp-card-body">
                    <ul class="divewp-status-list">
                        <?php foreach ($counts['danger'] as $tab_id => $data): ?>
                            <li>
                                <?php 
                                $items = array();
                                foreach ($this->insights_data[$tab_id]['data'] as $key => $item) {
                                    $value = is_array($item['value']) ? $item['value']['status'] : $item['value'];
                                    if (strpos($this->insights_data[$tab_id]['instance']->get_pill_class($key, $value), 'status-pill-danger') !== false) {
                                        $items[] = $key;
                                    }
                                }
                                ?>
                                <a href="javascript:void(0);" class="divewp-tab-link" data-tab="<?php echo esc_attr($tab_id); ?>" data-tooltip="<?php echo esc_attr(implode(', ', $items)); ?>">
                                    <?php echo esc_html($data['name']); ?>
                                    <span class="divewp-count-badge"><?php echo esc_html($data['count']); ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
        <?php
    }
}