<?php
/**
 * Security Insights functionality for DiveWP
 *
 * This class provides security-related insights and recommendations.
 *
 * @package DiveWP
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_Security_Insights {
    /**
     * Status constants
     */
    const STATUS_GOOD = 'success';
    const STATUS_WARNING = 'warning';
    const STATUS_CRITICAL = 'danger';
    const STATUS_INFO = 'info';

    /**
     * WordPress Filesystem instance
     *
     * @var WP_Filesystem_Base
     */
    private $wp_filesystem;

    /**
     * Constructor
     */
    public function __construct() {
        $this->init_filesystem();
    }

    /**
     * Initialize WordPress Filesystem
     */
    private function init_filesystem() {
        global $wp_filesystem;

        if (!function_exists('WP_Filesystem')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        if (!WP_Filesystem()) {
            return;
        }

        $this->wp_filesystem = $wp_filesystem;
    }

    /**
     * Get security data
     *
     * @since 1.0.0
     * @return array Security insights data
     */
    public function get_security_data() {
        return array(
            'SSL/HTTPS' => array(
                'value' => $this->check_ssl(),
                'recommended' => __('Should be enabled', 'divewp'),
                'impact' => __('High', 'divewp')
            ),
            'File Permissions' => array(
                'value' => $this->check_file_permissions(),
                'recommended' => __('Important WordPress files and directories should have proper read/write permissions', 'divewp'),
                'impact' => __('High', 'divewp')
            ),
            'Admin Username' => array(
                'value' => $this->check_admin_user(),
                'recommended' => __('Should not be "admin"', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'Database Prefix' => array(
                'value' => $this->check_db_prefix(),
                'recommended' => __('Should be custom', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'File Editor' => array(
                'value' => $this->check_file_editor(),
                'recommended' => __('Should be disabled', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'Debug Mode' => array(
                'value' => $this->check_debug_mode(),
                'recommended' => __('Should be disabled in production', 'divewp'),
                'impact' => __('Medium', 'divewp')
            )
        );
    }

    /**
     * Get check thresholds
     *
     * @since 1.0.0
     * @return array Check thresholds and status mappings
     */
    protected function get_check_thresholds() {
        return array(
            'status_map' => array(
                self::STATUS_GOOD => array(
                    'No Issues',
                    'No admin user',
                    'Custom',
                    'Disabled'
                ),
                self::STATUS_WARNING => array(
                    'File based',
                    'Partially secure',
                    'Default'
                ),
                self::STATUS_CRITICAL => array(
                    'Issues Found',
                    'Admin user exists',
                    'Default (wp_)',
                    'Enabled'
                )
            ),
            'ssl_map' => array(
                self::STATUS_GOOD => array('Enabled'),
                self::STATUS_CRITICAL => array('Disabled')
            ),
            'file_permissions' => array(
                'wp-config.php' => '0444',
                'wp-content' => '0755',
                'uploads' => '0755'
            )
        );
    }

    /**
     * Get status pill class
     *
     * @since 1.0.0
     * @param string $key The setting key
     * @param mixed $value The current value
     * @return string The status pill class
     */
    public function get_pill_class($key, $value) {
        $thresholds = $this->get_check_thresholds();

        // Special handling for SSL check
        if ($key === 'SSL/HTTPS') {
            foreach ($thresholds['ssl_map'] as $status => $phrases) {
                foreach ($phrases as $phrase) {
                    if ($value === $phrase) {
                        return 'status-pill-' . $status;
                    }
                }
            }
        }

        // Handle array values (like from check_file_permissions)
        if (is_array($value)) {
            $value = $value['status'];
        }

        // Regular status map checks
        foreach ($thresholds['status_map'] as $status => $phrases) {
            foreach ($phrases as $phrase) {
                if (strpos($value, $phrase) !== false) {
                    return 'status-pill-' . $status;
                }
            }
        }

        // Default to warning if no match found
        return 'status-pill-' . self::STATUS_WARNING;
    }

    /**
     * Check SSL status
     *
     * @since 1.0.0
     * @return string SSL status
     */
    private function check_ssl() {
        return is_ssl() ? __('Enabled', 'divewp') : __('Disabled', 'divewp');
    }

    /**
     * Check file permissions
     *
     * @since 1.0.0
     * @return array File permissions status
     */
    private function check_file_permissions() {
        if (!$this->wp_filesystem) {
            return array(
                'status' => __('Unable to check permissions', 'divewp'),
                'tooltip' => __('WordPress Filesystem API not available', 'divewp')
            );
        }

        $issues = array();
        $tooltip = '';
        $thresholds = $this->get_check_thresholds();
        $permissions = $thresholds['file_permissions'];

        foreach ($permissions as $file => $recommended_perm) {
            $path = ($file === 'wp-config.php') ? ABSPATH . $file : WP_CONTENT_DIR . '/' . $file;
            if ($this->wp_filesystem->exists($path)) {
                $current_perm = $this->wp_filesystem->getchmod($path);
                if ($this->is_permission_too_open($current_perm, $recommended_perm)) {
                    $issues[] = $file;
                    $tooltip .= sprintf(
                        /* translators: 1: File name 2: Recommended permission value */
                        __('%1$s permissions are too open. Should be %2$s or more restrictive.', 'divewp'),
                        $file,
                        $recommended_perm
                    ) . "\n";
                }
            }
        }

        if (empty($issues)) {
            return array(
                'status' => __('No Issues', 'divewp'),
                'tooltip' => __('All file permissions are properly configured.', 'divewp')
            );
        }

        return array(
            'status' => __('Issues Found', 'divewp'),
            'tooltip' => $tooltip
        );
    }

    /**
     * Check if permission is too open
     *
     * @since 1.0.0
     * @param string $current_perm Current permission
     * @param string $recommended_perm Recommended permission
     * @return bool True if permission is too open
     */
    private function is_permission_too_open($current_perm, $recommended_perm) {
        $current = is_numeric($current_perm) ? octdec($current_perm) : octdec(decoct($current_perm));
        $recommended = is_numeric($recommended_perm) ? octdec($recommended_perm) : octdec($recommended_perm);
        return $current > $recommended;
    }

    /**
     * Check admin username
     *
     * @since 1.0.0
     * @return string Admin username status
     */
    private function check_admin_user() {
        $user = get_user_by('login', 'admin');
        return $user ? __('Admin user exists', 'divewp') : __('No admin user', 'divewp');
    }

    /**
     * Check database prefix
     *
     * @since 1.0.0
     * @return string Database prefix status
     */
    private function check_db_prefix() {
        global $wpdb;
        return $wpdb->prefix === 'wp_' ? __('Default (wp_)', 'divewp') : __('Custom', 'divewp');
    }

    /**
     * Check file editor status
     *
     * @since 1.0.0
     * @return string File editor status
     */
    private function check_file_editor() {
        return defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT ? 
            __('Disabled', 'divewp') : 
            __('Enabled', 'divewp');
    }

    /**
     * Check debug mode status
     *
     * @since 1.0.0
     * @return string Debug mode status
     */
    private function check_debug_mode() {
        return (defined('WP_DEBUG') && WP_DEBUG) ? 
            __('Enabled', 'divewp') : 
            __('Disabled', 'divewp');
    }

    /**
     * Render security data
     *
     * @since 1.0.0
     * @param array $security_data Security data to render
     * @return void
     */
    public function render_security_data($security_data) {
        if (empty($security_data)) {
            echo '<p>' . esc_html__('No security data available.', 'divewp') . '</p>';
            return;
        }

        echo '<h3>' . esc_html__('Security Insights', 'divewp') . '</h3>';
        echo '<table class="divewp-table">';
        echo '<tr><th>' . esc_html__('Check', 'divewp') . '</th><th>' . esc_html__('Status', 'divewp') . '</th><th>' . esc_html__('Recommended', 'divewp') . '</th><th>' . esc_html__('Security Impact', 'divewp') . '</th></tr>';
        
        foreach ($security_data as $key => $data) {
            $value = is_array($data['value']) ? $data['value']['status'] : $data['value'];
            $tooltip = is_array($data['value']) ? $data['value']['tooltip'] : '';
            
            echo '<tr>';
            echo '<td><strong>' . esc_html__($key, 'divewp') . '</strong></td>';
            echo '<td><span class="status-pill ' . esc_attr($this->get_pill_class($key, $data['value'])) . '"' . 
                 ($tooltip ? ' data-tooltip="' . esc_attr($tooltip) . '"' : '') . '>' . 
                 esc_html($value) . '</span></td>';
            echo '<td>' . esc_html($data['recommended']) . '</td>';
            echo '<td>' . esc_html($data['impact']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';

        echo '<div class="security-recommendations no-print">';
        $this->render_security_recommendations();
        echo '</div>';
    }

    private function render_security_recommendations() {
        echo '<h3>' . __('Security Recommendations', 'divewp') . '</h3>';
        echo '<ul>';
        
        // SSL Configuration
        echo '<li><strong>' . __('SSL/HTTPS:', 'divewp') . '</strong> ';
        echo __('Secure communication is essential for modern websites:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Enable SSL certificate for your domain', 'divewp') . '</li>';
        echo '<li>' . __('Force HTTPS for all pages', 'divewp') . '</li>';
        echo '<li>' . __('Ensure proper SSL configuration', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';
        
        // Access Security
        echo '<li><strong>' . __('Access Control:', 'divewp') . '</strong> ';
        echo __('Protect access to your WordPress installation:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Use strong admin username and password', 'divewp') . '</li>';
        echo '<li>' . __('Implement two-factor authentication', 'divewp') . '</li>';
        echo '<li>' . __('Limit login attempts', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';
        
        // File Security
        echo '<li><strong>' . __('File Protection:', 'divewp') . '</strong> ';
        echo __('Secure your WordPress files and configuration:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Disable file editing in WordPress admin', 'divewp') . '</li>';
        echo '<li>' . __('Protect wp-config.php and .htaccess', 'divewp') . '</li>';
        echo '<li>' . __('Set proper file permissions', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';
        
        // Database Security
        echo '<li><strong>' . __('Database Security:', 'divewp') . '</strong> ';
        echo __('Protect your database from unauthorized access:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Use custom database prefix', 'divewp') . '</li>';
        echo '<li>' . __('Regular database backups', 'divewp') . '</li>';
        echo '<li>' . __('Secure database credentials', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';

        echo '</ul>';

        // Add warning box
        echo '<div class="divewp-notice divewp-notice-warning">';
        echo '<p><strong>' . __('Important:', 'divewp') . '</strong> ';
        echo __('Security is an ongoing process. Regularly update WordPress core, themes, and plugins. Monitor your security logs and implement a security plugin for additional protection.', 'divewp');
        echo '</p>';
        echo '</div>';
    }
}
