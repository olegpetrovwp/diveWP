<?php
/**
 * Update Checker functionality for DiveWP
 *
 * @package DiveWP
 * @since 1.0.1
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_Update_Checker {
    const API_ENDPOINT = 'https://raw.githubusercontent.com/olegpetrovwp/divewp/main/metadata.json';
    const DOWNLOAD_BASE = 'https://github.com/olegpetrovwp/divewp/releases/download/';

    private $plugin_basename;
    private $plugin_slug = 'divewp';
    private $update_data = null;

    public function __construct() {
        $this->plugin_basename = plugin_basename(DIVEWP_PLUGIN_DIR . 'divewp.php');
        
        // Hook into WordPress update system
        add_filter('site_transient_update_plugins', array($this, 'check_for_updates'));
        add_filter('transient_update_plugins', array($this, 'check_for_updates'));
        add_filter('plugins_api', array($this, 'inject_update_info'), 10, 3);
        
        // Clear cache when WordPress checks for updates
        add_action('upgrader_process_complete', array($this, 'clear_update_cache'));
        add_action('delete_site_transient_update_plugins', array($this, 'clear_update_cache'));
    }

    public function check_for_updates($transient) {
        if (empty($transient) || !is_object($transient)) {
            return $transient;
        }

        if ($this->update_data === null) {
            $this->update_data = $this->get_update_data();
        }

        if (!empty($this->update_data) && version_compare(DIVEWP_VERSION, $this->update_data->new_version, '<')) {
            $transient->response[$this->plugin_basename] = $this->update_data;
        }

        return $transient;
    }

    private function get_update_data() {
        $cached = get_transient('divewp_update_data');
        if ($cached !== false) {
            return $cached;
        }

        // First try with wp_safe_remote_get
        $raw_response = wp_safe_remote_get(self::API_ENDPOINT, array(
            'timeout' => 5, // Reduced timeout
            'sslverify' => false, // Temporarily disable SSL verify
            'headers' => array(
                'Accept' => 'application/json',
                'User-Agent' => 'WordPress/' . get_bloginfo('version')
            )
        ));

        // If failed, try direct file_get_contents as fallback
        if (is_wp_error($raw_response)) {
            error_log('DiveWP Update Error (WP HTTP API): ' . $raw_response->get_error_message());
            
            // Try with file_get_contents as fallback
            $ctx = stream_context_create(array(
                'http' => array(
                    'timeout' => 5,
                    'header' => 'Accept: application/json'
                ),
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false
                )
            ));
            
            $json_data = @file_get_contents(self::API_ENDPOINT, false, $ctx);
            if ($json_data === false) {
                error_log('DiveWP Update Error: Failed to fetch update data using fallback method');
                return false;
            }
            
            $data = json_decode($json_data);
        } else {
            $response_code = wp_remote_retrieve_response_code($raw_response);
            if ($response_code !== 200) {
                error_log('DiveWP Update Error: Invalid response code ' . $response_code);
                return false;
            }
            
            $data = json_decode(wp_remote_retrieve_body($raw_response));
        }

        if (empty($data) || !is_object($data)) {
            error_log('DiveWP Update Error: Invalid response format');
            return false;
        }

        $update_data = $this->prepare_update_data($data);
        if ($update_data) {
            set_transient('divewp_update_data', $update_data, 12 * HOUR_IN_SECONDS);
        }

        return $update_data;
    }

    private function prepare_update_data($data) {
        if (!isset($data->version)) {
            return false;
        }

        return (object) array(
            'id' => $this->plugin_basename,
            'slug' => $this->plugin_slug,
            'plugin' => $this->plugin_basename,
            'new_version' => $data->version,
            'url' => isset($data->url) ? $data->url : '',
            'package' => self::DOWNLOAD_BASE . "divewp-{$data->version}.zip",
            'icons' => array(),
            'banners' => array(),
            'banners_rtl' => array(),
            'tested' => isset($data->tested) ? $data->tested : '',
            'requires_php' => isset($data->requires_php) ? $data->requires_php : '',
            'compatibility' => new stdClass()
        );
    }

    public function inject_update_info($result, $action, $args) {
        if ($action !== 'plugin_information' || $args->slug !== $this->plugin_slug) {
            return $result;
        }

        $data = $this->get_update_data();
        if (!$data) {
            return $result;
        }

        return (object) array(
            'name' => 'DiveWP',
            'slug' => $this->plugin_slug,
            'version' => $data->new_version,
            'author' => 'Oleg Petrov',
            'requires' => '5.3.18',
            'tested' => $data->tested,
            'requires_php' => $data->requires_php,
            'sections' => array(
                'description' => 'DiveWP - WordPress Performance Analyzer and Optimization Tool',
                'changelog' => isset($data->sections->changelog) ? $data->sections->changelog : 'Please see changelog on our website.'
            ),
            'download_link' => $data->package
        );
    }

    public function clear_update_cache() {
        delete_transient('divewp_update_data');
        $this->update_data = null;
    }
} 