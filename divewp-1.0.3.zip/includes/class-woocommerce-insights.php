<?php
/**
 * WooCommerce Insights functionality for DiveWP
 *
 * This class provides WooCommerce-related insights and recommendations.
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    die(__('Direct access not permitted.', 'divewp'));
}

class DiveWP_WooCommerce_Insights {
    /**
     * Status constants
     */
    const STATUS_GOOD = 'success';
    const STATUS_WARNING = 'warning';
    const STATUS_CRITICAL = 'danger';
    const STATUS_INFO = 'info';

    private $cart_fragments_status = null;

    public function __construct() {
        // Add hook to check scripts at the right time
        add_action('admin_enqueue_scripts', array($this, 'check_cart_fragments_status'), 20);
    }

    public function check_cart_fragments_status() {
        if (!$this->is_woocommerce_active()) {
            $this->cart_fragments_status = __('Not applicable', 'divewp');
            return;
        }

        if (!wp_script_is('wc-cart-fragments', 'registered')) {
            $this->cart_fragments_status = __('Optimized', 'divewp');
            return;
        }

        if (!wp_script_is('wc-cart-fragments', 'enqueued')) {
            $this->cart_fragments_status = __('Optimized', 'divewp');
            return;
        }

        $this->cart_fragments_status = __('Not optimized', 'divewp');
    }

    /**
     * Get WooCommerce related insights data
     *
     * @since 1.0.0
     * @return array Array of WooCommerce insights data
     */
    public function get_woocommerce_data() {
        if (!$this->is_woocommerce_active()) {
            return array();
        }

        return array(
            'Cart Fragments' => array(
                'value' => $this->check_cart_fragments(),
                'recommended' => __('Disable if not using mini-cart in header/menu', 'divewp'),
                'impact' => __('High', 'divewp')
            ),
            'Session Handler' => array(
                'value' => $this->check_session_handler(),
                'recommended' => __('Use database sessions for multi-server setups', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'Order Cleanup' => array(
                'value' => $this->check_order_cleanup(),
                'recommended' => __('Archive orders older than 30 days', 'divewp'),
                'impact' => __('Medium', 'divewp')
            ),
            'Product Revisions' => array(
                'value' => $this->check_product_revisions(),
                'recommended' => __('Keep max 10 revisions per product', 'divewp'),
                'impact' => __('Medium', 'divewp')
            )
        );
    }

    /**
     * Get check thresholds
     *
     * @since 1.0.0
     * @return array Check thresholds and status mappings
     */
    protected function get_check_thresholds() {
        return array(
            'status_map' => array(
                self::STATUS_GOOD => array(
                    'Detected',
                    'Enabled',
                    'Managed by plugin',
                    'Optimized',
                    'Database (Recommended)',
                    'Below threshold',
                    'No Issues'
                ),
                self::STATUS_WARNING => array(
                    'File based',
                    'Consider cleanup',
                    'High revision count',
                    'Checking...',
                    'Managed by',
                    'Detected via',
                    'Partially configured'
                ),
                self::STATUS_CRITICAL => array(
                    'Not detected',
                    'Not optimized',
                    'Issues Found',
                    'Needs cleanup',
                    'Not applicable',
                    'Disabled',
                    'Not available'
                )
            ),
            'numeric_thresholds' => array(
                'Order Cleanup' => array(
                    'optimal' => 500,    // orders
                    'warning' => 1000    // orders
                ),
                'Product Revisions' => array(
                    'optimal' => 100,    // revisions
                    'warning' => 500     // revisions
                )
            )
        );
    }

    /**
     * Get status pill class
     *
     * @since 1.0.0
     * @param string $key The setting key
     * @param mixed $value The current value
     * @return string The status pill class
     */
    public function get_pill_class($key, $value) {
        $thresholds = $this->get_check_thresholds();

        // Handle array values (like from check_session_handler)
        if (is_array($value)) {
            // Extract numeric value if it exists
            $numeric_value = $this->extract_numeric_value($value['status']);
            if ($numeric_value !== false) {
                $value = $numeric_value;
            } else {
                $value = $value['status'];
            }
        }

        // Check numeric thresholds first
        if (isset($thresholds['numeric_thresholds'][$key])) {
            $numeric_value = $this->extract_numeric_value($value);
            if ($numeric_value !== false) {
                if ($numeric_value <= $thresholds['numeric_thresholds'][$key]['optimal']) {
                    return 'status-pill-' . self::STATUS_GOOD;
                } elseif ($numeric_value <= $thresholds['numeric_thresholds'][$key]['warning']) {
                    return 'status-pill-' . self::STATUS_WARNING;
                }
                return 'status-pill-' . self::STATUS_CRITICAL;
            }
        }

        // Check status map for text-based statuses
        foreach ($thresholds['status_map'] as $status => $phrases) {
            foreach ($phrases as $phrase) {
                if (strpos($value, $phrase) !== false) {
                    return 'status-pill-' . $status;
                }
            }
        }

        // Default to warning if no match found
        return 'status-pill-' . self::STATUS_WARNING;
    }

    /**
     * Extract numeric value from string
     *
     * @since 1.0.0
     * @param string $value The value to extract from
     * @return int|false Numeric value or false if not found
     */
    private function extract_numeric_value($value) {
        if (is_numeric($value)) {
            return intval($value);
        }
        
        if (preg_match('/(\d+)/', $value, $matches)) {
            return intval($matches[1]);
        }
        
        return false;
    }

    /**
     * Check cart fragments optimization status
     *
     * @since 1.0.0
     * @return string Status of cart fragments optimization
     */
    private function check_cart_fragments() {
        // Before hook runs, return Optimized (matches most common case)
        if ($this->cart_fragments_status === null) {
            return __('Optimized', 'divewp');
        }
        return $this->cart_fragments_status;
    }

    /**
     * Check WooCommerce session handler configuration
     *
     * @since 1.0.0
     * @return array Session handler status and tooltip
     */
    private function check_session_handler() {
        global $wpdb;

        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            return array(
                'status' => __('Not applicable', 'divewp'),
                'tooltip' => __('WooCommerce is not installed or activated', 'divewp')
            );
        }

        // Check if sessions table exists
        $table_name = $wpdb->prefix . 'woocommerce_sessions';
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $table_name
        ));

        // Check if there are any queries to the sessions table
        if ($table_exists) {
            return array(
                'status' => __('Database (Recommended)', 'divewp'),
                'tooltip' => __('Using database sessions - optimal for performance and multi-server setups', 'divewp')
            );
        }

        // If no database sessions detected, check for file-based sessions
        $session_dir = WP_CONTENT_DIR . '/wc-sessions';
        if (file_exists($session_dir)) {
            return array(
                'status' => __('File based', 'divewp'),
                'tooltip' => __('Using file-based sessions. Consider switching to database sessions for better reliability.', 'divewp')
            );
        }

        // Default response if we can't definitively determine the session type
        return array(
            'status' => __('Custom Handler', 'divewp'),
            'tooltip' => __('Session handler type could not be definitively determined. Please verify your configuration.', 'divewp')
        );
    }

    /**
     * Check order cleanup status
     *
     * @since 1.0.0
     * @return array Order cleanup status and tooltip
     */
    private function check_order_cleanup() {
        global $wpdb;
        $old_orders = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} 
            WHERE post_type = 'shop_order' 
            AND post_status = 'wc-completed' 
            AND post_date < DATE_SUB(NOW(), INTERVAL 30 DAY)"
        );
        
        return array(
            'status' => sprintf(__('%d old orders', 'divewp'), $old_orders),
            'tooltip' => sprintf(
                __('You have %d completed orders older than 30 days. Keep below 500 old orders for optimal database performance.', 'divewp'),
                $old_orders
            )
        );
    }

    /**
     * Check product revisions status
     *
     * @since 1.0.0
     * @return array Product revisions status and tooltip
     */
    private function check_product_revisions() {
        global $wpdb;
        $revision_count = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} 
            WHERE post_type = 'revision' 
            AND post_parent IN (
                SELECT ID FROM {$wpdb->posts} 
                WHERE post_type = 'product'
            )"
        );
        
        return array(
            'status' => sprintf(__('%d revisions', 'divewp'), $revision_count),
            'tooltip' => sprintf(
                __('You have %d product revisions. Keep below 500 total revisions, with 5-10 revisions per product maximum.', 'divewp'),
                $revision_count
            )
        );
    }

    /**
     * Check if WooCommerce is active
     *
     * @since 1.0.0
     * @return bool True if WooCommerce is active
     */
    private function is_woocommerce_active() {
        return class_exists('WooCommerce');
    }

    /**
     * Render WooCommerce data
     *
     * @since 1.0.0
     * @param array $woocommerce_data WooCommerce data to render
     * @return void
     */
    public function render_woocommerce_data($woocommerce_data) {
        if (empty($woocommerce_data)) {
            echo '<p>' . esc_html__('No WooCommerce data available or the plugin is not installed.', 'divewp') . '</p>';
            return;
        }

        echo '<h3>' . esc_html__('WooCommerce Performance Insights', 'divewp') . '</h3>';
        echo '<table class="divewp-table">';
        echo '<tr><th>' . esc_html__('Check', 'divewp') . '</th><th>' . esc_html__('Current Value', 'divewp') . '</th><th>' . esc_html__('Recommended', 'divewp') . '</th><th>' . esc_html__('Performance Impact', 'divewp') . '</th></tr>';
        
        foreach ($woocommerce_data as $key => $data) {
            $value = is_array($data['value']) ? $data['value']['status'] : $data['value'];
            $tooltip = is_array($data['value']) ? $data['value']['tooltip'] : '';
            
            // Get pill class without counting or logging
            $pill_class = $this->get_pill_class($key, $data['value']);
            
            echo '<tr>';
            echo '<td><strong>' . esc_html__($key, 'divewp') . '</strong></td>';
            echo '<td><span class="status-pill ' . esc_attr($pill_class) . '"' . 
                 ($tooltip ? ' data-tooltip="' . esc_attr($tooltip) . '"' : '') . '>' . 
                 esc_html($value) . '</span></td>';
            echo '<td>' . esc_html($data['recommended']) . '</td>';
            echo '<td>' . esc_html($data['impact']) . '</td>';
            echo '</tr>';
        }
        
        echo '</table>';

        echo '<div class="woocommerce-recommendations no-print">';
        $this->render_woocommerce_recommendations();
        echo '</div>';
    }

    private function render_woocommerce_recommendations() {
        echo '<h3>' . __('WooCommerce Recommendations', 'divewp') . '</h3>';
        echo '<ul>';
        
        // Cart Performance
        echo '<li><strong>' . __('Cart Performance:', 'divewp') . '</strong> ';
        echo __('Optimize cart functionality for better performance and user experience:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Cart Fragments: Consider disabling if not needed. Cart fragments make AJAX requests to update mini-cart, but can impact performance. Only keep enabled if you show cart totals in header/menu.', 'divewp') . '</li>';
        echo '<li>' . __('Session Handler: Use database session handler instead of files for better reliability and scalability. Database sessions work better with load balancers and multiple servers.', 'divewp') . '</li>';
        echo '<li>' . __('AJAX Cart: Enable AJAX cart updates to prevent full page reloads. This provides a smoother experience while reducing server load.', 'divewp') . '</li>';
        echo '<li>' . __('Cart Cache: Consider using page caching with cart fragments disabled. Fragment caching can be enabled for logged-out users.', 'divewp') . '</li>';
        echo '<li>' . __('Mini Cart: If using mini cart, optimize its AJAX updates and consider lazy loading cart contents.', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';
        
        // Data Management 
        echo '<li><strong>' . __('Data Management:', 'divewp') . '</strong> ';
        echo __('Keep your store database clean and efficient for optimal performance:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Order Cleanup: Regularly clean completed orders older than 30 days. Archive or delete old orders to prevent database bloat.', 'divewp') . '</li>';
        echo '<li>' . __('Product Revisions: Limit product revisions to 5-10 per product. Too many revisions impact database size and performance.', 'divewp') . '</li>';
        echo '<li>' . __('Database Optimization: Regularly optimize WooCommerce tables by removing post revisions, auto-drafts, and orphaned metadata.', 'divewp') . '</li>';
        echo '<li>' . __('Session Cleanup: Clear expired sessions weekly. Old sessions can accumulate and slow database queries.', 'divewp') . '</li>';
        echo '<li>' . __('Image Optimization: Compress product images and use appropriate sizes. Large images impact page load times.', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';

        // Performance Optimization
        echo '<li><strong>' . __('Performance Optimization:', 'divewp') . '</strong> ';
        echo __('Implement these optimizations for better store performance:', 'divewp');
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Caching: Use page caching with proper exclusions for cart, checkout, and my account pages.', 'divewp') . '</li>';
        echo '<li>' . __('Query Optimization: Index important columns and optimize product queries. Consider using ElasticSearch for large catalogs.', 'divewp') . '</li>';
        echo '<li>' . __('CDN Usage: Use CDN for static assets including product images. This reduces server load and improves global access.', 'divewp') . '</li>';
        echo '<li>' . __('PHP Settings: Optimize PHP settings like memory_limit and max_execution_time for better performance.', 'divewp') . '</li>';
        echo '</ul>';
        echo '</li>';

        echo '</ul>';

        // Replace the existing warning box with this new style
        echo '<div class="seo-important-notice">';
        echo '<div class="notice notice-info">';
        echo '<p><strong>' . __('Pro Tip:', 'divewp') . '</strong> ';
        echo __('Before implementing performance optimizations:', 'divewp') . '</p>';
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        echo '<li>' . __('Keep regular backups of your store data and files', 'divewp') . '</li>';
        echo '<li>' . __('Have a rollback plan for each optimization', 'divewp') . '</li>';
        echo '</ul>';
        echo '</div>';
        echo '</div>';
    }
}
