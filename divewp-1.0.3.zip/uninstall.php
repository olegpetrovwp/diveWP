<?php
/**
 * DiveWP Uninstall
 *
 * Uninstalling DiveWP deletes tables, options, and other site data.
 *
 * @package DiveWP
 * @since 1.0.0
 * @license GPL-2.0+
 */

// Exit if uninstall not called from WordPress
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Verify user capabilities
if (!current_user_can('activate_plugins')) {
    return;
}

global $wpdb;

// Delete custom table
$table_name = $wpdb->prefix . 'divewp_email_log';
$wpdb->query("DROP TABLE IF EXISTS {$table_name}");

// Delete plugin options
$options_to_delete = array(
    'divewp_version',
    'divewp_installed_time',
    'divewp_last_check_time'
);

foreach ($options_to_delete as $option) {
    delete_option($option);
}

// Delete transients
$wpdb->query(
    "DELETE FROM {$wpdb->options} 
    WHERE option_name LIKE '%_transient_divewp_%' 
    OR option_name LIKE '%_transient_timeout_divewp_%'"
);

// Clear any scheduled hooks
wp_clear_scheduled_hook('divewp_daily_cleanup');
wp_clear_scheduled_hook('divewp_cron_job');

// Clear cache
wp_cache_flush();

// Always flush rewrite rules
flush_rewrite_rules();
